# Stage 2 independent expanded lipid scan: execution report

Run date: 2026-10-03

This report implements the separate amendment in
`docs/preregistration_stage2.md`. It does not alter, combine with, or replace
the Stage 1 Cadby 2022 multiplicity family.

## Data provenance and scope

The exposure source is Landstra et al. 2026, *Population-based genome-wide
association study of plasma complex lipid species* (Nature Communications,
doi: 10.1038/s41467-026-72542-1). The paper reports 970 measured lipid species
in Rhineland Study (n=6,096), with a public Model 1 meta-GWAS of the 913 lipid
species overlapping EPIC-Potsdam (combined per-trait n approximately 7,118;
GCP001611). Model 1 adjusts for age, sex and genetic principal components, not
routine lipid levels; it is therefore the prespecified Stage 2 primary model.

The implementation used the paper's public Supplementary Data 14 for initial
instrument construction, then matched instruments directly to Dupuytren
GWAS GCST90301252. Full per-lipid GCP001611 files are public but were not
downloaded because no lipid passed the prespecified discovery gate; they remain
required for any future candidate-specific regional colocalization.

## Instrument flow

- The supplementary table contained 8,777 Model 1 significant
  lipid-variant rows, representing 647 lipid species and 1,171 unique rsIDs.
  All passed P < 5e-8 and F > 10 after standard errors were reconstructed from
  the reported beta and two-sided p value.
- After re-clumping per lipid against the same 1000 Genomes European reference
  used in Stage 1 (r2 < 0.001, 10 Mb), 1,381 rows across 646 lipid species
  remained. The 1,381 rows represented 102 unique rsIDs because lipid traits
  share many metabolic loci.
- 207 rows were absent from the LD reference and 7,189 rows were removed for
  LD with a stronger instrument of the same lipid. These exclusions are
  retained in `results/tables/stage2_landstra_clumping_audit.tsv`.
- Of the 102 unique rsIDs, 88 directly matched GCST90301252. At lipid level,
  444 traits were estimable, 195 lost all matched variants during conservative
  allele harmonization (mostly palindromic sites without exposure allele
  frequency), and 7 had no direct outcome match.

## Primary MR result

No Stage 2 lipid passed BH FDR < 0.05 across the 444 estimable lipid species.
The smallest nominal p value was for PE(16:0/18:1), using three instruments:
beta=0.132, SE=0.0502, P=0.00872, BH FDR=0.181. It is not a candidate and must
not be interpreted as causal evidence.

The next two nominal signals were PE(18:0/18:1) (P=0.00951; FDR=0.181) and
CE(FA20:2) (P=0.0121; FDR=0.181). The author-defined lipid-class Simes test was
also null: the smallest class P was 0.0873 for phosphatidylethanolamines, with
class FDR=0.503.

## Power and interpretation

The achieved-se minimum-detectable-effect audit gives a median detectable
risk-increasing odds ratio of 1.70 per 1-SD lipid at 80% power under
family-wise alpha 0.05/444 (interquartile range 1.44-2.04). Thus this screen
is not sensitive to many modest causal effects. In addition, LD-reference
availability was non-uniform by lipid class (simulated chi-square P<1e-4), so
the null result is not equally informative for every class.

## Prespecified decision

The Stage 2 discovery gate is not met. FinnGen outcome replication,
colocalization, single-cell candidate localization, target MR, CMap and drug
prioritization are therefore not run. The scientifically valid next deliverable
is a combined, power-qualified negative genetic screen rather than a
candidate-mechanism paper. Any future transcriptomic study must be explicitly
framed as a separate non-causal fascia cell-state project.

# GSE173252: primary fascia-state results

## Analysis status

This analysis used the author-distributed GSE173252 Seurat object, retaining
the raw RNA count slot and the author's original metadata. The object has
35,250 cells from three Dupuytren fascia samples, three Skoog fascia samples,
and three healthy dermis samples. After author-flagged doublet removal and
prespecified donor-wise MAD quality control, 30,896 cells remained.

The primary disease comparison is Dupuytren versus Skoog fascia. Dermis is a
contextual reference only. All differential-expression tests use donor-by-state
pseudo-bulk samples with edgeR quasi-likelihood models; individual cells are
never treated as biological replicates.

## State localization

The author cluster 3, labelled here as `Pathogenic_PDPN_FAP_like`, expresses
PDPN, FAP, POSTN, SCX, TNFRSF12A and CTHRC1 in the author object. This is a
reproducibility-oriented label for the disease-enriched state already reported
by the source study, not a newly inferred lineage or a newly discovered cell
type.

After quality control, this state was represented by 39, 2,064, and 1,068
cells in DD1, DD2, and DD3 respectively (2.2%, 51.7%, and 39.8% of the
mesenchymal compartment). It did not meet the minimum-cell threshold in any
Skoog donor. Consequently, there is no valid within-state Dupuytren-versus-
Skoog pseudo-bulk contrast for this state. Its apparent disease localization is
shown descriptively only and must not be reported as a composition p-value.

The broad mesenchymal pseudo-bulk contrast is estimable (three donors per
fascia group). It identifies 257 genes at within-state BH FDR < 0.05, but this
contrast combines different mesenchymal states. It therefore supports a tissue-
level disease signature rather than a cell-intrinsic signature of any one
state. State-restricted contrasts are available only for common resident and
pericyte-like states, and remain exploratory given the three-donor groups.

## Prespecified MD audit: negative for specificity

Across donor-by-mesenchymal-state summaries with at least 30 cells, the Lu 2025
MD score correlated with the ECM/collagen score at Spearman rho = 0.955 and
with the TGF-beta response score at rho = 0.928. Removing genes that overlap
with the four control programs did not solve the problem (rho = 0.939 and
0.906, respectively). Both exceed the preregistered absolute-rho threshold of
0.80.

Therefore, **MD is removed from the title, primary hypothesis, and headline
conclusions**. These data do not distinguish it from canonical fibrotic
activation in this setting. The defensible project framing is now:

> *Single-cell localization of pathological fibroblast states and lipid-
> metabolism programs in Dupuytren fascia, with genetic lipid screens reported
> as rigorously negative supplementary evidence.*

## Deliverables

- `results/tables/scrna_analysis_cell_metadata.tsv`: standardized cell-level
  metadata and QC inclusion indicator.
- `results/tables/scrna_donor_program_scores.tsv`: donor-by-state UCell score
  medians.
- `results/tables/scrna_md_specificity_correlations.tsv`: the preregistered MD
  audit.
- `results/tables/scrna_mesenchyme_state_composition.tsv`: descriptive state
  fractions.
- `results/tables/scrna_pseudobulk_de.tsv`: donor-level edgeR results.
- `results/figures/fascia_state_composition.png` and
  `results/figures/md_program_collinearity.png`: directly reportable QC and
  decision figures.

## Independent bulk direction check

GSE75152 contains 12 Dupuytren and 12 control hand connective-tissue samples
on the Illumina HumanWG-6 v3 microarray. Deposited IDAT files were processed
using negative-control background correction and between-array normalization
(`neqc`), then collapsed to one highest-IQR probe per gene symbol before limma
analysis. Of 9,293 genes shared
with the discovery mesenchymal pseudo-bulk result, 84 passed BH FDR < 0.05 in
both datasets and 80/84 (95.2%) had concordant direction. This is directional
validation of a mixed-tissue signature, not independent proof of a specific
cell state.

Bulk program scoring (mean per-gene standardized expression) showed increased
ECM/collagen, TGF-beta response and LRRC15-myofibroblast programs, with reduced
fatty-acid oxidation and glycerophospholipid metabolism programs. The MD score
was also increased, but this does **not** reverse its removal from the headline:
the single-cell specificity audit shows it is inseparable from the canonical
fibrotic programs in the discovery data.

## Sensitivity audit and lipid-program decision

The broad mesenchymal pseudo-bulk contrast was stable under all six
leave-one-donor-out analyses: every *shared* baseline BH-significant gene
retained its effect direction, and whole-transcriptome Spearman correlations of log-fold
changes ranged from 0.916 to 0.967. Repeating the comparison after retaining
all non-doublet cells (rather than applying the extra donor-wise MAD filters)
also retained the direction of all baseline significant genes (rho = 0.999).
The descriptive PDPN/FAP-like localization was similarly unchanged by this QC
choice.

The pre-specified lipid-metabolism gene sets do **not** yield a target-ready
triangulation: no individual member was BH-significant and directionally
concordant in both the single-cell mesenchymal pseudo-bulk and GSE75152 bulk
validation. The sphingolipid score was elevated in the six-donor single-cell
mesenchymal comparison but was not reproduced in bulk. Thus no lipid enzyme,
receptor, transport protein, drug lookup, or target-MR analysis is advanced
from this data set. The tissue-level metabolic-program changes remain an
observational context, not a drug-target claim.

## Second bulk cohort and directional triangulation

The public-cohort audit identified GSE31356 as the only additional direct
Dupuytren tissue comparison suitable for this project: three patient-matched
diseased/non-diseased pairs. Its small size yielded no gene passing genome-wide
BH FDR, so it is used strictly as a paired, nominal direction check. Combining
it with GSE75152 using a platform-agnostic signed-evidence procedure identified
four genes meeting the prespecified three-dataset directional rule: `ALDH3A2`,
`NOVA1`, `RAB33A`, and `MYO1B`.

This four-gene set is exploratory. It is not a target list: the paired cohort
has only three pairs, and no genetic, perturbation, protein-level, or functional
evidence has been added. `ALDH3A2` is a biologically interesting lipid-aldehyde
metabolism gene and is lower in the PDPN/FAP-like state descriptively, but this
localization is not an adequate basis for a therapeutic claim.

An explicit Dupuytren GWAS locus audit found no genome-wide significant regional
signal within 500 kb of the three assessable autosomal genes. The source GWAS
file has no X-chromosome variants, so it cannot provide genetic context for
`RAB33A`. All four remain cross-transcriptomic exploratory genes, not genetic
risk genes.

## Restricted large-cohort external direction check

The public Zenodo 14017529 workbook from Galán Novella et al. contains labelled
sample-level values from 26 Dupuytren and 17 control palmar-fascia samples. It
only provides the 237 gene rows selected by the source authors, so it cannot be
treated as a whole-transcriptome replication cohort. It was checksum-verified
and reanalysed only for genes fixed before this workbook was opened.

Of the 84 genes already BH-significant in both GSE173252 broad mesenchyme and
GSE75152, 13 were represented in the Zenodo selected list. All 13 had matching
Dupuytren-versus-control direction in all three sources: `CLEC11A`, `COL5A1`,
`CTHRC1`, `LRRC17`, `MAFB`, `MMP11`, `NPTX2`, `P4HA3`, `PHKG1`, `SLC38A5`,
`SPARC`, `TGFBI`, and `TNFSF4`. This supports broad pathological
mesenchymal/ECM remodeling, but it is restricted-set direction evidence, not
an unbiased 13/13 replication rate. None of `ALDH3A2`, `NOVA1`, `RAB33A`, or
`MYO1B` occurred in the selected list, so this cohort neither supports nor
refutes those exploratory candidates.

## Interpretation limits

This work does not show a real lineage transition, causal lipid action, or a
therapeutic effect. The author object is a small discovery dataset; independent
Dupuytren data and bulk-tissue direction checks are required before elevating
any gene, metabolic program, or state-restricted contrast to a biological
conclusion.

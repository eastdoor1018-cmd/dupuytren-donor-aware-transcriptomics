# Stage 2 amendment: independent expanded lipid scan

Freeze date: 2026-10-03, before inspecting any Dupuytren association generated
from the Landstra 2026 exposure data.

## Rationale and separation from Stage 1

The prespecified Cadby 2022 scan produced no BH-FDR-positive lipid. Those
results, thresholds and files remain frozen. Stage 2 is a new, separately
labelled multiplicity family prompted by the subsequently identified Landstra
2026 study; it is not a threshold change or a post-hoc reanalysis of Stage 1.

## Exposure and outcome

The primary Stage 2 exposure is Model 1 from the publicly released
Rhineland+EPIC-Potsdam meta-GWAS (GCP001611). Model 1 adjusts for age, sex and
genetic principal components but not routine lipids, lipid-lowering treatment
or fasting status. Model 2 is reserved for sensitivity analysis because
conditioning on conventional lipids may induce bias.

The public meta-analysis covers 913 lipid species shared by both cohorts. The
paper's Supplementary Data 14 supplies genome-wide significant associations
for initial instrument construction. Full per-trait summary statistics remain
the required source for candidate colocalization if any lipid survives.

GCST90301252 remains the primary Dupuytren outcome. FinnGen R13
M13_DUPUTRYEN is downloaded and analyzed only after Stage 2 produces at least
one BH-FDR-positive primary candidate, thereby keeping replication independent
and avoiding an unplanned search across outcome definitions.

## Instrument construction and MR

- Include exposure associations at P < 5e-8 and F > 10.
- Reconstruct SE from the reported two-sided p value and beta where the
  supplementary table omits SE; retain the calculation in the audit table.
- Re-clump every lipid using the same 1000 Genomes European reference,
  r2 < 0.001 and 10 Mb window used in Stage 1.
- Infer a missing exposure non-effect allele only when its reported effect
  allele matches one allele of the biallelic Dupuytren outcome record.
  Unresolved and palindromic variants are removed conservatively.
- Use Wald ratio for one SNP, random-effects IVW for at least two SNPs,
  weighted median and MR-RAPS for at least three SNPs, and MR-Egger only for at
  least ten SNPs. Apply the already frozen sensitivity and heterogeneity rules.
- Apply BH FDR across all estimable Stage 2 lipid species; report Bonferroni in
  parallel. Stage 1 and Stage 2 p values are never pooled into one adaptive
  family.

## Confirmatory gate

Only a Stage 2 lipid with BH FDR < 0.05 proceeds to FinnGen outcome
replication. A Tier 1 designation still requires directionally concordant
replication at P < 0.05, regional colocalization PP.H4 >= 0.80, and no strong
reverse-causality or horizontal-pleiotropy warning. Single-cell localization
and drug analyses remain downstream of this genetic gate.

If Stage 2 is null, no instrument or significance threshold is relaxed. The
causal lipid mainline stops and the combined result is reported as a
power-qualified negative study or replaced by a separately framed
transcriptomic question without causal lipid claims.

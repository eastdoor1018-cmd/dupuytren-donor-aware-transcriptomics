# R environment setup (macOS)

The project now includes a self-contained Apple-silicon environment with R
4.4.3. RStudio is optional; the pipeline itself runs from the terminal and does
not depend on RStudio. The Homebrew/system-R steps below are only an alternative
for someone rebuilding outside this project.

## Ready-to-use project environment

Nothing needs to be installed globally. From the project directory, either run
one command through the wrapper:

```sh
sh scripts/run_in_env.sh Rscript environment/check.R
```

or activate it for a terminal session:

```sh
source environment/activate.sh
R --version
Rscript environment/check.R
```

The environment contains R 4.4.3, Python 3.12, PLINK 1.9, compilers and all
listed CRAN/Bioconductor packages. RStudio can be pointed to the R executable at
`.mamba/envs/dupuytren/bin/R`, but RStudio is not required.

## Alternative system-wide setup

## 1. Install system prerequisites

Install Apple's command-line tools:

```sh
xcode-select --install
```

Install Homebrew if it is not already present, then install the small set of
build tools used by R packages:

```sh
brew install git curl wget cmake pkg-config gcc libxml2 openssl@3 hdf5 plink
```

Install the current R release from CRAN for Apple silicon or Intel as
appropriate: <https://cran.r-project.org/bin/macosx/>. Do not mix an Intel R
with Apple-silicon libraries.

## 2. Verify R is visible

Close and reopen the terminal, then run:

```sh
R --version
Rscript --version
```

Both commands should report version 4.4 or newer.

For the prespecified local LD clumping, download a European 1000 Genomes LD
reference in PLINK `bed/bim/fam` format. Then set the prefix (without `.bed`) and
PLINK executable in your shell, for example:

```sh
export DUPUYTREN_LD_PREFIX="/absolute/path/to/1kg_eur"
export PLINK_BIN="$(command -v plink)"
```

The analysis intentionally stops before MR if these are missing. This prevents
silently substituting the publication's looser locus definition for the
preregistered r2 < 0.001 rule. The exact LD reference release and checksum must
be recorded in `results/logs/` when it is obtained.

## 3. Check and install the project environment

From this project directory:

```sh
Rscript environment/check.R
Rscript environment/setup.R
```

The installer creates a project-local `renv` lockfile. If an individual package
fails, keep the full error log in `results/logs/` and rerun the installer; it is
safe to rerun.

## 4. Packages used

Statistical genetics: `TwoSampleMR`, `MendelianRandomization`, `mr.raps`,
`MRPRESSO`, `coloc`, `susieR`, `ieugwasr`.

Expression analysis: `Seurat`, `SingleCellExperiment`, `scater`, `scuttle`,
`scran`, `edgeR`, `limma`, `UCell`, `AUCell`, `fgsea`, `GEOquery`.

Infrastructure and plotting: `renv`, `BiocManager`, `data.table`, `dplyr`,
`readr`, `arrow`, `yaml`, `jsonlite`, `ggplot2`, `patchwork`.

## 5. Optional but recommended

- At least 32 GB RAM for the full single-cell stage; 16 GB can work with sparse
  matrices and the mesenchymal subset but is slower.
- At least 80 GB free storage. The staged downloader avoids the roughly 120 GB
  all-lipid download; regional files and single-cell matrices still require
  room.
- No API token is stored in the repository. If OpenGWAS is used for LD lookup,
  set `OPENGWAS_JWT` only in your shell or user-level `.Renviron`.

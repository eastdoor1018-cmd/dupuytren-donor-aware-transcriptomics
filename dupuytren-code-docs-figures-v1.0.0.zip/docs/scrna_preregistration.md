# Parallel single-cell fascia-state study

Freeze date: 2026-10-03

## Relationship to the lipid MR screen

This is a separate transcriptomic study. The two lipid MR discovery families
were FDR-negative, so no transcriptomic pattern in this project will be called
a lipid-mediated causal mechanism, a genetic replication, or a drug target.
The negative MR work is retained as a complementary, power-qualified result.

## Primary question

In Dupuytren palmar fascia, is the PDPN+/FAP+ pathogenic mesenchymal
population a reproducible pathological state distinguishable from resident
fibroblasts and myofibroblast activation, and does the Lu et al. 2025
mesenchymal-drift (MD) signature add information beyond ECM, TGF-beta and
myofibroblast programs?

## Novelty boundary

The project does **not** claim to newly discover PDPN+/FAP+ pathogenic cells,
the resident-fibroblast to myofibroblast trajectory, or simple expansion of a
myofibroblast state: these are already central findings of the GSE173252 source
publication, and an independently posted 2026 compositional analysis also
reports expansion of an activated myofibroblast state. The potentially new
question is narrower: whether an author-defined cross-lineage MD-related
signature is separable from ordinary ECM/TGF-beta/myofibroblast activation in
the known disease-associated fascia state. The analysis will not reuse the
external compositional repository's code, atlas or unreviewed conclusions.

## Discovery data and primary comparison

The discovery dataset is GSE173252. Its primary anatomical contrast is three
Dupuytren fascia samples versus three non-lesional Skoog fascia samples. The
three healthy dermis samples are retained for broad cell-type context only and
are never pooled with Skoog fascia as the primary control. Each GEO sample is
one donor-level replicate unless the public metadata proves otherwise; no
pairing is assumed from matching sample suffixes.

## Data processing and inference

- Start from the public RNA count layer. Quality-control thresholds are
  calculated separately per sample with robust MAD rules, recorded before
  differential testing, and applied only after minimal removal of empty/
  clearly low-complexity droplets.
- The public author annotations are used as an annotation reference, then
  audited with canonical markers. They are not treated as independent
  validation.
- Batch-corrected/integrated representations can be used for UMAP and
  clustering only. All differential-expression and gene-set inference uses
  unintegrated raw RNA counts aggregated to donor-by-cell-state pseudobulk.
- The principal fibroblast state comparison is resident fibroblast,
  PDPN+/FAP+ pathogenic mesenchymal cell, and myofibroblast-like cell, subject
  to annotation support. Major non-mesenchymal compartments are descriptive.
- A cell state must have at least 20 cells in a donor and at least two donors
  in each primary condition for inferential pseudo-bulk comparison.
- edgeR quasi-likelihood analysis estimates Dupuytren versus Skoog effects.
  Genes and pathways are reported with effect size, FDR, donor coverage and
  leave-one-donor-out direction stability. Cell-level P values are never used
  as biological replication.

## Program analysis and MD safeguard

Programs are scored with the author-supplied Lu 2025 MD gene set plus fixed
ECM/collagen, TGF-beta, ACTA2/TAGLN myofibroblast, EMT/EndMT, cell-cycle,
senescence, wound-repair and lipid-metabolism gene sets. Scores summarize
cells but condition comparisons are performed on donor-by-state medians or
pseudobulk gene-set tests.

The manuscript may use the term "MD-related program" only if all of the
following are true: (1) its donor-level absolute Spearman correlation with
ECM/collagen and myofibroblast scores is below 0.80; (2) a non-overlapping
subset of MD genes shows directionally stable donor-level change; and (3) the
finding is not solely explained by cell-cycle composition. Otherwise the study
uses "pathological fibroblast activation/identity instability" and removes MD
from the title and central claim.

## Validation hierarchy

1. GSE75152 bulk Dupuytren/control tissue: direction-only validation of robust
   pseudobulk genes and fixed programs; it cannot validate a cell type.
2. PRJNA607098/PRJNA623191 disease-only nodule single-cell data: localization
   support for the state signature only; it has no non-disease comparator.
3. GSE273293 gluteal muscle contracture fascia: cross-fascia convergence only,
   never a Dupuytren replication.

## Interpretation ceiling

The strongest allowable claim is that public transcriptomic data identify and
locate a disease-associated palmar-fascia mesenchymal state and its programs.
The study does not establish lineage conversion in vivo, prove MD, demonstrate
drug efficacy, or establish a causal role for any lipid.

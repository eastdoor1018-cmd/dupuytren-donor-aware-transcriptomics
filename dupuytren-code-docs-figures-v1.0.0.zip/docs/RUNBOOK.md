# Execution runbook

Every stage writes a machine-readable audit table and a log. Do not skip a failed
stage by manually editing its output.

## Stage 0: audit environment and registry

```sh
sh scripts/run_in_env.sh Rscript environment/check.R
sh scripts/run_in_env.sh python scripts/project_status.py
```

## Stage 1: acquire small public source tables and metadata

```sh
sh scripts/run_in_env.sh python scripts/download_public_data.py --tier bootstrap
sh scripts/run_in_env.sh Rscript R/01_prepare_mr_inputs.R
```

The bootstrap tier downloads the Cadby supplementary association tables and
dataset metadata. It does not download all 596 full GWAS files.

## Stage 2: acquire the primary outcome and run all-lipid MR

```sh
sh scripts/run_in_env.sh python scripts/download_public_data.py --tier primary-mr
sh scripts/run_in_env.sh Rscript R/02_run_mr.R
```

Review `results/tables/mr_primary.tsv` and the harmonization/exclusion audit.

## Stage 3: replication and regional colocalization

```sh
sh scripts/run_in_env.sh python scripts/download_public_data.py --tier candidates \
  --candidate-table results/tables/mr_candidates.tsv
sh scripts/run_in_env.sh Rscript R/03_colocalization.R
```

FinnGen data are release-specific. The downloader records the release and will
stop with an actionable message if the public path has changed rather than
silently substituting a phenotype.

## Stage 4: single-cell and bulk localization

```sh
sh scripts/run_in_env.sh python scripts/download_public_data.py --tier expression
sh scripts/run_in_env.sh Rscript R/04_single_cell.R
sh scripts/run_in_env.sh Rscript R/05_bulk_validation.R
```

## Stage 5: integrated ranking

```sh
sh scripts/run_in_env.sh Rscript R/06_integrate_evidence.R
```

Only Tier 1 candidates continue to target MR, perturbation-signature lookup and
safety PheWAS.

## Stage 6: power and missingness audit

```sh
sh scripts/run_in_env.sh Rscript R/07_power_and_missingness.R
```

This stage is mandatory for a negative discovery result. It distinguishes lack
of a large detectable effect from lack of power and tests whether reference-panel
loss is concentrated in particular lipid classes.

## Independent Stage 2 amendment

Stage 2 is governed by `docs/preregistration_stage2.md` and does not overwrite
the Stage 1 result family.

```sh
sh scripts/run_in_env.sh python scripts/download_public_data.py --tier stage2-bootstrap
sh scripts/run_in_env.sh Rscript R/08_prepare_stage2_inputs.R
sh scripts/run_in_env.sh python scripts/download_public_data.py --tier stage2-outcome

MR_EXPOSURE_PATH=data/derived/stage2_mr_exposure_instruments.tsv \
MR_OUTCOME_PATH=data/derived/stage2_GCST90301252_instrument_associations.tsv \
MR_OUTPUT_PREFIX=stage2_ \
  sh scripts/run_in_env.sh Rscript R/02_run_mr.R

POWER_CLUMP_PATH=results/tables/stage2_landstra_clumping_audit.tsv \
POWER_COVERAGE_PATH=results/tables/stage2_mr_instrument_coverage.tsv \
POWER_MR_PATH=results/tables/stage2_mr_primary.tsv \
POWER_OUTPUT_PREFIX=stage2_ \
  sh scripts/run_in_env.sh Rscript R/07_power_and_missingness.R
```

FinnGen replication, colocalization and expression localization remain gated
on at least one Stage 2 primary BH-FDR-positive lipid.

## Negative-screen visual summary

After both primary MR tables exist, generate the transparent figure and its
underlying top-nominal-signal table:

```sh
sh scripts/run_in_env.sh Rscript R/09_plot_genetic_screens.R
```

## Parallel single-cell fascia-state study

The separate protocol is in `docs/scrna_preregistration.md`. First inspect the
public author object and record its actual assay and metadata schema before
mapping any annotation fields:

```sh
sh scripts/run_in_env.sh python scripts/prepare_gse173252_manifest.py
sh scripts/run_in_env.sh Rscript R/10_inspect_GSE173252.R
sh scripts/run_in_env.sh Rscript R/11_standardize_GSE173252_metadata.R
sh scripts/run_in_env.sh Rscript R/12_fascia_state_pseudobulk.R
sh scripts/run_in_env.sh Rscript R/13_report_fascia_state_results.R
sh scripts/run_in_env.sh Rscript R/14_prepare_GSE75152_bulk.R
sh scripts/run_in_env.sh Rscript R/05_bulk_validation.R
sh scripts/run_in_env.sh Rscript R/15_integrate_scrna_bulk.R
sh scripts/run_in_env.sh Rscript R/16_plot_bulk_validation.R
sh scripts/run_in_env.sh Rscript R/17_scrna_robustness_audit.R
sh scripts/run_in_env.sh Rscript R/18_mesenchymal_program_analysis.R
sh scripts/run_in_env.sh Rscript R/19_prepare_GSE31356_bulk.R
sh scripts/run_in_env.sh Rscript R/20_cross_cohort_bulk_integration.R
sh scripts/run_in_env.sh Rscript R/21_triangulated_gene_localization.R
sh scripts/run_in_env.sh Rscript R/22_plot_triangulated_gene_localization.R
sh scripts/run_in_env.sh Rscript R/23_exploratory_gene_locus_audit.R
sh scripts/run_in_env.sh Rscript R/26_prepare_Zenodo14017529_bulk.R
sh scripts/run_in_env.sh Rscript R/27_external_direction_validation.R
sh scripts/run_in_env.sh Rscript R/28_plot_external_direction_validation.R
sh scripts/run_in_env.sh Rscript R/24_build_evidence_matrix.R
sh scripts/run_in_env.sh Rscript R/25_plot_study_design.R
```

`R/12` uses donor-level pseudo-bulk inference only for cell states represented
by at least the prespecified minimum number of donors in both fascia groups.
It writes the MD specificity decision automatically; do not retain an MD claim
if that decision says to remove it from the title.

# Public Dupuytren bulk-cohort audit

Audit date: 2026-10-03.

## Included cohorts

| Cohort | Design | Role | Handling |
|---|---|---|---|
| GSE75152 | 12 Dupuytren, 12 control hand connective-tissue samples | Larger independent direction/pathway validation | Primary bulk validation; unpaired limma model |
| GSE31356 | 3 matched Dupuytren/non-diseased tissue pairs | Small directional replication | Pair-adjusted limma model; nominal same-direction evidence only |
| Zenodo 14017529 | 26 Dupuytren, 17 control palmar-fascia samples | Restricted external direction check | Sample-level values are public only for the authors' 237 selected DE rows; not a transcriptome-wide validation set |

GSE75152 was preprocessed from the deposited Illumina IDAT files using `neqc`
(negative-control background correction and between-array normalization).
GSE31356 was preprocessed from its deposited Affymetrix CEL files using RMA.
Each was then mapped by its GEO platform table and collapsed to the one
highest-IQR probe per gene symbol. The processed GEO series matrices are used
only for sample metadata checks, not expression inference.

The Zenodo 14017529 workbook was checksum-verified against its public MD5 and
contains 26 `DD` and 17 `CTR` columns. Its 237 reported rows resolve to 236
unique symbols after deterministic duplicate handling. Reanalysis on log2(value
+ 1) reproduces the authors' effect directions for all 236 rows (Pearson
effect-size correlation 0.965). However, this is a selected gene table rather
than a full expression matrix; it is never used for fresh DE discovery, pathway
enrichment, a denominator-based replication rate, or target prioritization.

## Excluded candidate

GSE269317 includes cultured skin fibroblasts, a WNT4 perturbation, and a
Dupuytren/unaffected-wrist comparison. Its series-matrix record has no
expression matrix and its biological setting is not fascia tissue. It is
therefore excluded from the tissue-level cross-cohort meta analysis; it is not
silently substituted for a fascia replication cohort.

## Cross-cohort rule

Raw log-fold changes are not pooled across platforms. For transparent
exploration, the two bulk studies are combined only as a sample-size-weighted
signed Stouffer statistic. A gene receives *directional triangulation* status
only if it passes BH FDR < 0.05 in the GSE173252 broad-mesenchymal pseudo-bulk
and GSE75152, has nominal P < 0.05 in GSE31356, and has the same effect
direction in all three datasets. This is a prioritization rule, not proof of
causality or a target-discovery criterion.

# Analysis preregistration and decision log

Freeze date: 2026-10-03

## Primary question

Which circulating complex lipid species have genetic evidence for a causal
effect on Dupuytren disease, share a causal regional signal with the disease,
and localize to disease-relevant palmar-fascia cell states?

## Confirmatory analysis

The discovery exposure is the unadjusted Cadby 2022 lipid GWAS. Instruments
must have P < 5e-8, F > 10 and be clumped at European LD r2 < 0.001 within
10 Mb. One-SNP estimates use the Wald ratio; two or more variants use
random-effects IVW. Weighted median and MR-RAPS are added at three or more
variants; MR-Egger is reported only at ten or more. BH FDR < 0.05 is the primary
multiplicity criterion and Bonferroni results are also reported.

The primary outcome is GCST90301252. Replication is evaluated in both axes:
Cadby exposures against FinnGen and GeneRISK exposures against GCST90301252.
Names must agree at class, total carbon, double-bond and modification level;
ambiguous mappings are not called replication.

Candidates undergo reverse MR, Steiger directionality, heterogeneity,
leave-one-out and pleiotropy checks. HDL, LDL and triglycerides enter MVMR only
for the strongest candidates. BMI and diabetes are not automatically adjusted
because they may be mediators.

## Computationally staged acquisition

To avoid downloading every full lipid GWAS before any association can survive,
the first pass uses the authors' published genome-wide significant independent
variant table for every lipid. Variants are re-clumped at the prespecified
r2 threshold using ancestry-matched reference LD. After the all-lipid FDR is
computed, full exposure summary statistics are downloaded for every surviving
candidate and every prespecified sensitivity candidate. This stage boundary is
computational only: no threshold, phenotype or direction is changed after seeing
the results.

## Colocalization

For each FDR-positive pair, the region is lead variant +/-500 kb. `coloc.abf`
is used for one-signal regions. SuSiE conditional colocalization is used where
ancestry-matched LD and evidence for multiple signals are available. Tier 1
requires PP.H4 >= 0.80 under the primary prior and is stress-tested across the
prespecified p12 grid. H4 is always interpreted together with H3.

## Expression localization

Single-cell inference uses donor-by-cell-type pseudobulk; cells are never
treated as independent replicates. Batch correction may aid visualization and
clustering but never supplies the inferential counts. The key contrast in
GSE173252 is Dupuytren fascia versus non-lesional Skoog fascia; healthy dermis
is a contextual, not anatomically matched, control.

MD-related, ECM, TGF-beta, myofibroblast, EMT/EndMT, senescence, wound repair and
lipid-metabolism programs are scored separately. In fibroblasts the term is
"MD-related pathological program/identity instability," not proof that the
cells underwent mesenchymal drift. If the MD score correlates at least 0.80 with
ECM or myofibroblast score, or loses disease/lipid-pathway association after
adjustment for ECM, TGF-beta and cell cycle, MD is removed from the title and
primary conclusion.

## Tier rules

Tier 1 requires all of: discovery FDR < 0.05; directionally concordant
replication P < 0.05; PP.H4 >= 0.80; and no strong reverse-causality or horizontal
pleiotropy warning. Tier 2 is consistent genetic evidence with incomplete or
moderate colocalization. Nominal or single-source findings remain exploratory
and do not enter drug claims.

## Null and failure paths

If no lipid passes FDR and replication, only the original publication's
predefined lipid classes/correlation clusters are tested. Instrument thresholds
are not relaxed. MR without colocalization is explicitly labeled compatible
with LD or pleiotropy. If expression results reduce to generic collagen
activation, MD language is removed and the lipid-causality plus cell-localization
story is retained.

## Interpretation ceiling

The strongest permitted conclusion is that genetic, colocalization and
transcriptomic evidence jointly support particular complex lipids and regulatory
genes in Dupuytren risk and locate them in specified pathological fascia cell
states. The study does not prove that circulating lipids directly induce MD and
does not establish clinical efficacy of any drug.


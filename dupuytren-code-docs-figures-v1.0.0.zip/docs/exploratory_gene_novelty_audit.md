# Exploratory-gene novelty and genetic-context audit

Audit date: 2026-10-03.

## Literature search scope

The following exact PubMed queries returned zero records on the audit date:

- `Dupuytren AND ALDH3A2`
- `Dupuytren AND NOVA1`
- `Dupuytren AND RAB33A`
- `Dupuytren AND MYO1B`

This supports only the limited wording that these genes were not retrieved by
these direct PubMed gene-plus-disease queries. It does not establish that the
observation is globally novel or unpublished, and it must not be described as
"first" in a manuscript.

## Genetic-context audit

The four genes are an exploratory directional-triangulation set, not GWAS
genes. Their Ensembl locations were mapped from GRCh38 to the GRCh37 build used
by GCST90301252. In ±500 kb windows around each locus, the best Dupuytren GWAS
P values are recorded in the automatically generated locus-audit table. None of
the three assessable autosomal loci is genome-wide significant. The outcome
GWAS file used here has no X-chromosome variants, so `RAB33A` has no genetic-
context inference from this source.

Accordingly, the paper must call these **cross-transcriptomic, directionally
supported exploratory genes**. They are not genetic risk genes, causal genes,
or therapeutic targets.

# External single-cell validation availability audit

Audit date: 2026-10-03. This audit is intentionally separate from the result
analysis so that an unavailable donor-level dataset is never replaced with a
less rigorous surrogate without disclosure.

## GSE273293: gluteal muscle contracture fascia

The GEO series metadata describes 10 fibrotic and 4 non-fibrotic iliotibial
band samples. However, the GEO supplementary-file manifest lists only one
10x-style matrix triplet (`GSM8425828_GMC01_*`) packaged in a 3.16 MB archive.
The SOFT record also contains a single GSM sample. Thus the current public GEO
deposit does not permit the promised donor-level 10-versus-4 pseudo-bulk
analysis.

Decision: **do not use GSE273293 for statistical cross-fascia validation at
this stage.** It may only be revisited if the complete per-donor matrices become
available from the authors or a verified public repository. A one-sample
analysis would be descriptive and would not satisfy the frozen protocol.

## PRJNA607098 / PRJNA623191: Dupuytren nodule single-cell data

These are disease-only nodule datasets and have no non-disease fascia control.
Even if their raw sequencing reads are processed, they cannot test disease
effect direction or validate cell-state frequency. They are eligible only for a
predefined qualitative localization check of a *pre-existing*, independently
supported signature. Since the lipid MR screens had no FDR-positive candidate,
no such candidate-level localization analysis is currently authorized.

## Galán Novella et al. 2025: 26 Dupuytren versus 17 control palmar fascia samples

The study reported genome-wide NGS expression profiling of 26 surgical
Dupuytren palmar-fascia samples and 17 non-Dupuytren control samples, together
with histological measurements. Its data-availability statement links to the
open Zenodo record [10.5281/zenodo.14017529](https://doi.org/10.5281/zenodo.14017529).
The public record contains `EXPRESSION VALUES.xlsx` (188.0 kB) and
`HISTOLOGY CUANTIFICATION VALUES.xlsx` (21.7 kB). It is therefore a genuinely
public external cohort, rather than a paper-only result.

The record describes the files as quantitative NGS and histology results. It
does **not** provide FASTQ files, a GEO/SRA accession, or a stated raw-count
archive. Consequently, it cannot support reprocessing or cell deconvolution
from raw reads. Its suitability for differential-expression validation depends
on the workbook intake check: we must verify that `EXPRESSION VALUES.xlsx`
contains sample-level expression values and an unambiguous 26-versus-17 group
label. If it instead contains only a precomputed differential-gene table, it
can validate overlap/direction only at the reported-result level, not provide
an independent reanalysis.

Decision: **prioritize this cohort as the next external bulk-validation
dataset.** Do not call it a raw-RNA-seq replication until its table structure,
normalization scale, and sample annotations have been audited.

### Reproducible intake location

For the next analysis stage, save the unmodified Zenodo download at
`data/raw/zenodo/14017529/EXPRESSION VALUES.xlsx`. Its public MD5 checksum is
`867f682ea840d99fad08c345536c9702`; record a checksum match before importing.
The histology workbook is optional for expression validation and should not be
used to infer transcriptional replication.

## Consequence for the manuscript

The validation hierarchy is now:

1. GSE173252: discovery and donor-level pseudo-bulk state analysis.
2. GSE75152: independent bulk direction/pathway validation.
3. Galán Novella et al. 2025: public 26-versus-17 bulk result set, pending
   sample-level workbook intake and format audit.
4. GSE273293 and the nodule datasets: explicitly unavailable or non-comparative
   for the intended statistical validation; not used to manufacture a second
   single-cell replication claim.

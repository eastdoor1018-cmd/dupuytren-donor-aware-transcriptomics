# Stage 1 execution report

Run date: 2026-10-03

This is a computational screening report, not a biological conclusion. It is
kept separate from the preregistration and must not be used to change thresholds.

## Environment and source integrity

- Project-local R 4.4.3 and Python 3.12 environment passes all 28 required
  R-package checks.
- GCST90301252 contains 7,933,832 variants. Its observed MD5 is
  `901db2ceb4d5724c7d869ebbf562c11e`, identical to the GWAS Catalog metadata.
- Local LD uses the official OpenGWAS 1000 Genomes phase 3 EUR panel: 503
  individuals and 8,550,156 variants after the provider's SNP/MAF filtering.
- The Lu et al. Cell 2025 author supplement was parsed directly and yields a
  205-gene MD signature. No MD gene was inferred from article prose.

## Instrument flow

Cadby Supplementary Data 6 contained 1,269 independent rows selected by the
authors' unadjusted standard GWAS. After the prespecified P < 5e-8 and F > 10
checks, 1,255 lipid-variant rows entered LD processing.

- 262 rows were absent from the EUR reference panel and were conservatively
  excluded because r2 could not be verified.
- 28 rows were removed at r2 >= 0.001 within 10 Mb of a stronger instrument for
  the same lipid.
- 965 rows (300 unique SNPs) across 508 lipid traits remained.

All exclusions and reasons are in `results/tables/cadby_clumping_audit.tsv`.

## Primary MR screen

Of 508 instrumented lipid traits, 470 were estimable after direct outcome
matching and allele harmonization. Twenty-seven lost every matched variant at
harmonization, principally because an exposure allele frequency was unavailable
for safe resolution of palindromic variants; eleven had no direct outcome match.
No proxy substitutions were introduced after results were seen.

No lipid passed BH FDR < 0.05. The smallest unadjusted P value was for
`LPE(17:0) [sn2]` (P = 0.00236; BH FDR = 0.204). This finding is nominal and must
not be presented as causal evidence. Weighted-median, MR-RAPS, MR-PRESSO and
leave-one-out outputs were generated where the instrument count allowed;
MR-Egger was not run because no lipid had at least ten harmonized instruments.

## Prespecified null path

Neither category analysis passed multiplicity correction:

- 27 directly measured total-class phenotypes: minimum P = 0.0134 for Total PE;
  minimum class-level FDR = 0.212.
- 32 author-defined lipid classes assessed by Simes enrichment: minimum Simes
  P = 0.0240 for PE; BH FDR = 0.327.

The preregistered discovery gate is therefore not met. Under the protocol,
there are no Tier 1 candidates to send to candidate-specific colocalization,
single-cell gene localization or drug prioritization. Proceeding with nominal
lipids as if they were positive would violate the analysis plan.

## Missingness and detectable-effect audit

Reference-panel loss is not uniform across lipid classes (simulated chi-square
P < 1e-4). In particular, ether/plasmalogen phosphatidylethanolamine classes
lost a larger fraction of instrument rows than many other classes. Therefore,
the global null result must not be interpreted as equally informative for every
lipid class.

Using the achieved primary-model standard errors, the median minimum detectable
risk-increasing odds ratio at 80% power and family-wise alpha 0.05/470 is 1.55
per 1-SD higher lipid. The interquartile range is 1.37 to 1.84. The screen can
therefore exclude many large effects but is poorly powered for modest effects;
"no FDR-positive lipid" is not evidence that all complex lipids have no role.

## Stage 1 status

The Stage 1 discovery family is complete and remains negative. A separately
preregistered independent expanded scan was subsequently run without modifying
this result. Its protocol and result are in
`docs/preregistration_stage2.md` and `docs/stage2_results.md`.

# Dupuytren disease fascia-state study

This repository implements the preregistered analysis:

> circulating complex lipids -> Dupuytren disease Mendelian randomization ->
> replication and colocalization -> palmar-fascia single-cell localization ->
> target prioritization.

The project is deliberately split into a lightweight, reproducible acquisition
stage and an R statistical stage. Python uses only small metadata and published
lead-variant tables for the initial screen. Full lipid GWAS files are downloaded
only for prespecified candidates that advance to regional colocalization. This
avoids an unnecessary download of roughly 120 GB while preserving the planned
analysis.

## Quick start

1. Follow [`docs/R_SETUP.md`](docs/R_SETUP.md) to install R and system tools.
2. From the project root, run `sh scripts/run_in_env.sh Rscript environment/check.R`.
3. Run `sh scripts/run_in_env.sh Rscript environment/setup.R` only if the check reports missing R packages.
4. Run `sh scripts/run_in_env.sh python scripts/project_status.py` to audit data and configuration.
5. Follow the stage commands in [`docs/RUNBOOK.md`](docs/RUNBOOK.md).

The authoritative thresholds, inclusion rules, failure paths and interpretation
limits are frozen in [`docs/preregistration.md`](docs/preregistration.md) and
[`config/analysis.yaml`](config/analysis.yaml). Outputs are written under
`results/`; raw project references under `sources/` are never modified.

The original discovery family is complete and negative. The independently
preregistered expanded scan is also negative and is documented separately in
[`docs/preregistration_stage2.md`](docs/preregistration_stage2.md) and
[`docs/stage2_results.md`](docs/stage2_results.md); it is not a replacement for
the original analysis.

A separately frozen, non-causal single-cell fascia-state study is now the main
biological workstream. Its contrast definitions, safeguards against
pseudoreplication, MD interpretation rule and validation hierarchy are in
[`docs/scrna_preregistration.md`](docs/scrna_preregistration.md).
The completed primary single-cell and bulk direction-check results are in
[`docs/scrna_primary_results.md`](docs/scrna_primary_results.md); the external
single-cell availability limits are recorded in
[`docs/external_validation_audit.md`](docs/external_validation_audit.md).

## Project layout

- `config/`: data registry, thresholds and gene-set definitions
- `docs/`: preregistration, setup notes and execution runbook
- `environment/`: R environment installer and diagnostic script
- `R/`: MR, colocalization, bulk and single-cell analysis stages
- `scripts/`: data acquisition, validation and orchestration helpers
- `src/`: tested Python utilities
- `data/raw/`: downloaded public files (not versioned)
- `data/derived/`: harmonized intermediate files (not versioned)
- `results/`: tables, figures, logs and audit records (not versioned)

## Reproducibility principles

- The donor, not the cell, is the biological replicate.
- Cell-level causal forests are not used.
- A single-cell expression pattern is mechanism localization, not genetic
  replication or proof of causality.
- Tier 1 requires primary MR significance, directional replication,
  colocalization and no strong reverse-causality/pleiotropy warning.
- Mesenchymal drift is retained in the narrative only if its score is not a
  proxy for ECM, TGF-beta response or myofibroblast activation.

## Public release and data access

This repository contains the analysis code, computational-environment files,
non-restricted derived outputs, and figure files needed to inspect and rerun
the reported analyses. It does not redistribute raw GEO downloads, third-party
supplementary files, or reference panels. Those materials should be obtained
from their original providers using the accessions and download instructions in
the runbook.

The repository is released under the MIT License. A versioned archive of the
submission-ready release will be deposited in Zenodo; its DOI will be added
here after archival.

### Version 1.0.0 archive layout

For the initial web upload, the versioned release is provided as three archives:

- `dupuytren-code-docs-figures-v1.0.0.zip` contains code, configuration,
  documentation, environment specifications, non-restricted intermediate
  files, and figures.
- `dupuytren-scrna-derived-tables-v1.0.0.zip` contains the non-restricted
  single-cell derived result tables.
- `dupuytren-other-derived-tables-v1.0.0.zip` contains the remaining
  non-restricted derived result tables.

Download and unpack both archives into the same project directory before
following the runbook.

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dupuytren_lipidomics.catalog import gwas_catalog_bucket, gwas_catalog_directory


class CatalogTests(unittest.TestCase):
    def test_bucket_boundaries(self):
        self.assertEqual(gwas_catalog_bucket("GCST90301252"), "GCST90301001-GCST90302000")
        self.assertEqual(gwas_catalog_bucket("GCST90023981"), "GCST90023001-GCST90024000")

    def test_url(self):
        self.assertTrue(gwas_catalog_directory("GCST90301252").endswith("/GCST90301252/"))

    def test_invalid_accession(self):
        with self.assertRaises(ValueError):
            gwas_catalog_bucket("M13_DUPUTRYEN")


if __name__ == "__main__":
    unittest.main()


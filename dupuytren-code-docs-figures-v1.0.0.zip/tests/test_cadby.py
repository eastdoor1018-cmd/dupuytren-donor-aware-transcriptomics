import csv
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dupuytren_lipidomics.cadby import parse_supplementary_data_6


class CadbyParserTests(unittest.TestCase):
    def test_real_workbook_if_present(self):
        source = ROOT / "data/raw/cadby_2022/Cadby2022_Supplementary_Data_6.xlsx"
        if not source.exists():
            self.skipTest("bootstrap workbook not downloaded")
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "parsed.tsv"
            counts = parse_supplementary_data_6(source, output)
            self.assertGreater(counts["standard_signals"], 1000)
            with output.open(encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle, delimiter="\t"))
            self.assertEqual(len(rows), counts["standard_signals"])
            self.assertIn("effect_allele", rows[0])


if __name__ == "__main__":
    unittest.main()


from pathlib import Path

from openpyxl import Workbook

from dupuytren_lipidomics.landstra import parse_meta_model1


def test_parse_meta_model1(tmp_path: Path) -> None:
    source = tmp_path / "supp.xlsx"
    output = tmp_path / "parsed.tsv"
    wb = Workbook()
    ws = wb.active
    ws.title = "Supplementary Data 14"
    for _ in range(5):
        ws.append([])
    row = [None] * 22
    row[3:17] = [1, 40395195, "rs77320796", "A", "LPC(FA16:0)", -0.1597,
                  "--", 2.981e-17, "rs77320796", 2.981e-17, 60, 70,
                  "MFSD2A", "LPCs"]
    ws.append(row)
    wb.save(source)

    counts = parse_meta_model1(source, output)
    assert counts["rows_p_lt_5e_8"] == 1
    assert counts["unique_lipids"] == 1
    text = output.read_text()
    assert "rs77320796" in text
    assert "Rhineland+EPIC-Potsdam meta-analysis" in text

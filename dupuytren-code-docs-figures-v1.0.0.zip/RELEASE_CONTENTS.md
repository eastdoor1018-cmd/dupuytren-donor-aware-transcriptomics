# Public release contents

This release contains:

- analysis scripts in `R/`, `scripts/`, and `src/`;
- parameters and gene-set definitions in `config/`;
- environment and dependency specifications in `environment/` and `renv.lock`;
- execution, preregistration, and audit documentation in `docs/`;
- non-restricted derived tables in `data/derived/` and `results/tables/`; and
- publication figures in `results/figures/`.

The release deliberately excludes raw downloaded data, third-party
supplementary archives, and reference panels. Retrieve those from their
original sources using the accessions and checks documented in `docs/RUNBOOK.md`.

No new human-participant data were generated for this study.

from __future__ import annotations

import csv
import gzip
from pathlib import Path
from typing import TextIO


ALIASES = {
    "SNP": ("variant_id", "rsid", "rs_id", "SNP", "snp"),
    "chromosome": ("chromosome", "chr", "CHR"),
    "position": ("base_pair_location", "position", "pos", "BP"),
    "effect_allele": ("effect_allele", "EA", "A1"),
    "other_allele": ("other_allele", "OA", "A2"),
    "beta": ("beta", "effect", "BETA"),
    "se": ("standard_error", "se", "SE"),
    "pval": ("p_value", "pval", "P"),
    "eaf": ("effect_allele_frequency", "eaf", "EAF"),
}


def _open_text(path: Path) -> TextIO:
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8", errors="replace", newline="")
    return path.open("r", encoding="utf-8", errors="replace", newline="")


def resolve_columns(fieldnames: list[str]) -> dict[str, str]:
    resolved: dict[str, str] = {}
    for canonical, aliases in ALIASES.items():
        hit = next((name for name in aliases if name in fieldnames), None)
        if hit:
            resolved[canonical] = hit
    required = {"SNP", "effect_allele", "other_allele", "beta", "se"}
    missing = sorted(required - resolved.keys())
    if missing:
        raise ValueError(f"Summary statistics are missing canonical fields {missing}; header={fieldnames}")
    return resolved


def extract_variants(source: Path, variants: set[str], destination: Path) -> dict[str, int]:
    """Stream a summary-statistics file and retain requested rsIDs."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    scanned = matched = 0
    with _open_text(source) as source_handle:
        reader = csv.DictReader(source_handle, delimiter="\t")
        if reader.fieldnames is None:
            raise ValueError(f"No header in {source}")
        columns = resolve_columns(reader.fieldnames)
        output_fields = list(ALIASES.keys())
        with destination.open("w", encoding="utf-8", newline="") as output_handle:
            writer = csv.DictWriter(output_handle, fieldnames=output_fields, delimiter="\t")
            writer.writeheader()
            for row in reader:
                scanned += 1
                snp = row.get(columns["SNP"], "")
                if snp not in variants:
                    continue
                writer.writerow({field: row.get(columns[field], "") if field in columns else "" for field in output_fields})
                matched += 1
    return {"scanned": scanned, "matched": matched, "requested": len(variants)}


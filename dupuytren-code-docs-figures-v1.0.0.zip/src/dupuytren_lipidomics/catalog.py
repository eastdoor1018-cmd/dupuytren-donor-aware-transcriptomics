from __future__ import annotations

import hashlib
import json
import os
import shutil
import urllib.request
from pathlib import Path


def gwas_catalog_bucket(accession: str) -> str:
    """Return the GWAS Catalog 1000-accession directory for a GCST accession."""
    if not accession.startswith("GCST") or not accession[4:].isdigit():
        raise ValueError(f"Invalid GWAS Catalog accession: {accession}")
    number = int(accession[4:])
    low = ((number - 1) // 1000) * 1000 + 1
    high = low + 999
    return f"GCST{low:08d}-GCST{high:08d}"


def gwas_catalog_directory(accession: str) -> str:
    bucket = gwas_catalog_bucket(accession)
    return (
        "https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/"
        f"{bucket}/{accession}/"
    )


def sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download(url: str, destination: Path, timeout: int = 90) -> Path:
    """Download atomically; an existing non-empty file is kept."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and destination.stat().st_size > 0:
        return destination
    partial = destination.with_suffix(destination.suffix + ".part")
    request = urllib.request.Request(url, headers={"User-Agent": "dupuytren-lipid-study/0.1"})
    with urllib.request.urlopen(request, timeout=timeout) as response, partial.open("wb") as out:
        shutil.copyfileobj(response, out, length=1024 * 1024)
    os.replace(partial, destination)
    return destination


def write_manifest(records: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


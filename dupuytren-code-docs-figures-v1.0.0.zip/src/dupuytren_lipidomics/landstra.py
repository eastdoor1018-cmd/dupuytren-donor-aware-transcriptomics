from __future__ import annotations

import csv
from pathlib import Path

from openpyxl import load_workbook


LANDSTRA_HEADER = [
    "SNP",
    "lipid",
    "lipid_class",
    "chromosome",
    "position_hg19",
    "effect_allele",
    "other_allele",
    "beta",
    "se",
    "pval",
    "direction",
    "lead_snp",
    "lead_snp_pval",
    "nearby_gene",
    "source_model",
    "source_cohorts",
]


def parse_meta_model1(source: Path, destination: Path) -> dict[str, int]:
    """Parse the unadjusted Landstra 2026 meta-GWAS instrument table.

    Supplementary Data 14 reports the effect allele, beta and p value but not
    the non-effect allele or standard error. The latter is deliberately left
    blank here and reconstructed from beta/p in the audited R preparation
    stage. The non-effect allele is inferred only when the biallelic Dupuytren
    outcome record contains the reported exposure effect allele.
    """
    workbook = load_workbook(source, read_only=True, data_only=True)
    sheet = workbook["Supplementary Data 14"]
    destination.parent.mkdir(parents=True, exist_ok=True)
    counts = {
        "rows_seen": 0,
        "rows_p_lt_5e_8": 0,
        "unique_lipids": 0,
        "unique_snps": 0,
        "missing_rsid": 0,
    }
    lipids: set[str] = set()
    snps: set[str] = set()
    with destination.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=LANDSTRA_HEADER, delimiter="\t")
        writer.writeheader()
        for row in sheet.iter_rows(min_row=6, values_only=True):
            if not row[7]:
                continue
            counts["rows_seen"] += 1
            try:
                pval = float(row[10])
            except (TypeError, ValueError):
                continue
            if pval >= 5e-8:
                continue
            snp = "" if row[5] is None else str(row[5])
            lipid = str(row[7])
            counts["rows_p_lt_5e_8"] += 1
            counts["missing_rsid"] += int(not snp.startswith("rs"))
            if snp:
                snps.add(snp)
            lipids.add(lipid)
            writer.writerow(
                {
                    "SNP": snp,
                    "lipid": lipid,
                    "lipid_class": row[16],
                    "chromosome": row[3],
                    "position_hg19": row[4],
                    "effect_allele": row[6],
                    "other_allele": "",
                    "beta": row[8],
                    "se": "",
                    "pval": pval,
                    "direction": row[9],
                    "lead_snp": row[11],
                    "lead_snp_pval": row[12],
                    "nearby_gene": row[15],
                    "source_model": "Model 1",
                    "source_cohorts": "Rhineland+EPIC-Potsdam meta-analysis",
                }
            )
    counts["unique_lipids"] = len(lipids)
    counts["unique_snps"] = len(snps)
    return counts

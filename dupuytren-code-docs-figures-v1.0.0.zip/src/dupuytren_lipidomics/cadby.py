from __future__ import annotations

import csv
from pathlib import Path

from openpyxl import load_workbook


CANONICAL_HEADER = [
    "record_id", "lipid", "lipid_class", "SNP", "chromosome", "position_hg19",
    "effect_allele", "other_allele", "beta", "se", "pval",
    "beta_adjusted", "se_adjusted", "pval_adjusted", "direction",
    "standard_signal_rank", "adjusted_signal_rank",
]


def _is_signal(value: object) -> bool:
    return value not in (None, "", "-")


def parse_supplementary_data_6(source: Path, destination: Path) -> dict[str, int]:
    """Parse Cadby Supplementary Data 6, retaining primary standard-GWAS signals."""
    workbook = load_workbook(source, read_only=True, data_only=True)
    sheet = workbook[workbook.sheetnames[0]]
    destination.parent.mkdir(parents=True, exist_ok=True)
    counts = {"rows_seen": 0, "standard_signals": 0, "missing_rsid": 0}
    with destination.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CANONICAL_HEADER, delimiter="\t", extrasaction="ignore")
        writer.writeheader()
        for row in sheet.iter_rows(min_row=4, values_only=True):
            if row[0] is None:
                continue
            counts["rows_seen"] += 1
            if not _is_signal(row[15]):
                continue
            counts["standard_signals"] += 1
            if not row[3]:
                counts["missing_rsid"] += 1
            writer.writerow(dict(zip(CANONICAL_HEADER, row[:17])))
    return counts


def parse_supplementary_data_8(source: Path, destination: Path) -> dict[str, int]:
    """Parse independent-signal exposure replication reported by Cadby et al."""
    workbook = load_workbook(source, read_only=True, data_only=True)
    sheet = workbook[workbook.sheetnames[0]]
    header = [
        "record_id", "lipid", "lipid_class", "SNP", "chromosome", "position_hg19",
        "effect_allele", "other_allele", "beta_discovery", "se_discovery",
        "pval_discovery", "beta_validation", "se_validation", "pval_validation",
        "beta_meta", "se_meta", "pval_meta",
    ]
    destination.parent.mkdir(parents=True, exist_ok=True)
    rows = 0
    with destination.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(header)
        for row in sheet.iter_rows(min_row=4, values_only=True):
            if row[0] is None:
                continue
            writer.writerow(row[:17])
            rows += 1
    return {"rows": rows}


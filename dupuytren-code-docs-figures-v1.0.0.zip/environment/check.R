#!/usr/bin/env Rscript

required_version <- numeric_version("4.4.0")
current_version <- getRversion()
cat(sprintf("R version: %s\n", current_version))

issues <- character()
if (current_version < required_version) {
  issues <- c(issues, sprintf("R >= %s is required", required_version))
}

commands <- c("git", "curl", "cmake", "pkg-config", "gfortran")
paths <- Sys.which(commands)
for (cmd in commands) {
  ok <- nzchar(paths[[cmd]])
  cat(sprintf("%-12s %s%s\n", cmd, if (ok) "OK  " else "MISS", if (ok) paths[[cmd]] else ""))
}
if (!nzchar(paths[["git"]]) || !nzchar(paths[["curl"]]) || !nzchar(paths[["gfortran"]])) {
  issues <- c(issues, "git, curl and gfortran must be available on PATH")
}

required_packages <- c(
  "renv", "BiocManager", "data.table", "dplyr", "readr", "yaml",
  "jsonlite", "ggplot2", "patchwork", "arrow", "TwoSampleMR",
  "MendelianRandomization", "mr.raps", "MRPRESSO", "coloc", "susieR",
  "ieugwasr", "Seurat", "SingleCellExperiment", "edgeR", "limma",
  "scuttle", "scran", "scater", "UCell", "AUCell", "fgsea", "GEOquery",
  "illuminaio", "affy", "hgu133acdf"
)
installed <- rownames(installed.packages())
missing <- setdiff(required_packages, installed)
cat(sprintf("Installed required R packages: %d/%d\n", length(required_packages) - length(missing), length(required_packages)))
if (length(missing)) {
  cat("Missing packages:\n  ", paste(missing, collapse = ", "), "\n", sep = "")
  issues <- c(issues, "run: Rscript environment/setup.R")
}
if ("ieugwasr" %in% installed && utils::packageVersion("ieugwasr") < "1.2.0") {
  issues <- c(issues, "ieugwasr >= 1.2.0 is required for the installed TwoSampleMR")
}

if (length(issues)) {
  cat("\nEnvironment is not ready:\n")
  cat(paste0("- ", unique(issues), collapse = "\n"), "\n")
  quit(status = 1)
}

cat("\nEnvironment is ready.\n")

#!/usr/bin/env Rscript

options(repos = c(MRCIEU = "https://mrcieu.r-universe.dev", CRAN = "https://cloud.r-project.org"))

if (getRversion() < numeric_version("4.4.0")) {
  stop("R >= 4.4.0 is required; found ", getRversion())
}

bootstrap <- c("renv", "BiocManager", "remotes")
missing_bootstrap <- setdiff(bootstrap, rownames(installed.packages()))
if (length(missing_bootstrap)) install.packages(missing_bootstrap)

cran_packages <- c(
  "data.table", "dplyr", "readr", "tidyr", "purrr", "stringr",
  "yaml", "jsonlite", "digest", "openxlsx", "arrow", "ggplot2",
  "patchwork", "MendelianRandomization", "coloc", "susieR",
  "ieugwasr", "metafor", "broom", "future", "Seurat"
)
missing_cran <- setdiff(cran_packages, rownames(installed.packages()))
if (length(missing_cran)) install.packages(missing_cran)
if (!requireNamespace("ieugwasr", quietly = TRUE) || packageVersion("ieugwasr") < "1.2.0") {
  install.packages("ieugwasr", repos = c("https://mrcieu.r-universe.dev", "https://cloud.r-project.org"))
}

bioc_packages <- c(
  "SingleCellExperiment", "SummarizedExperiment", "edgeR", "limma",
  "scuttle", "scran", "scater", "UCell", "AUCell", "fgsea", "GEOquery",
  "BiocParallel", "AnnotationDbi", "org.Hs.eg.db", "illuminaio", "affy", "hgu133acdf"
)
missing_bioc <- setdiff(bioc_packages, rownames(installed.packages()))
if (length(missing_bioc)) BiocManager::install(missing_bioc, ask = FALSE, update = FALSE)

github_packages <- c(
  TwoSampleMR = "MRCIEU/TwoSampleMR",
  MRPRESSO = "rondolab/MR-PRESSO",
  mr.raps = "qingyuanzhao/mr.raps"
)
for (pkg in names(github_packages)) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    remotes::install_github(github_packages[[pkg]], upgrade = "never")
  }
}

lock_packages <- c(
  "renv", "BiocManager", cran_packages, bioc_packages,
  names(github_packages), "data.table", "dplyr", "readr", "yaml",
  "jsonlite", "arrow", "ggplot2", "ieugwasr"
)
renv::snapshot(
  project = ".", library = .libPaths()[1], lockfile = "renv.lock",
  packages = unique(lock_packages), prompt = FALSE, force = TRUE
)
cat("R environment installed and recorded in renv.lock\n")

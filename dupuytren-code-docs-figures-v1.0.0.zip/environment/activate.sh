#!/bin/sh
# Source this file from the project root:
#   source environment/activate.sh

_dupuytren_root="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
export MAMBA_ROOT_PREFIX="${_dupuytren_root}/.mamba"
export PATH="${_dupuytren_root}/.mamba/envs/dupuytren/bin:${PATH}"
export PLINK_BIN="${_dupuytren_root}/.mamba/envs/dupuytren/bin/plink"
if [ -f "${_dupuytren_root}/data/reference/EUR.bed" ]; then
  export DUPUYTREN_LD_PREFIX="${_dupuytren_root}/data/reference/EUR"
fi
unset _dupuytren_root

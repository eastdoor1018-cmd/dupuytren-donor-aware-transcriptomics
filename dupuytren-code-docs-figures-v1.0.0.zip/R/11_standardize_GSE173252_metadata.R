#!/usr/bin/env Rscript
source("R/utils.R")

input <- Sys.getenv("GSE173252_RDS_GZ", unset = "data/raw/geo/GSE173252/GSE173252_dd.rds.gz")
obj <- gse173252_author_object(input)
counts <- gse173252_raw_counts(obj)
meta <- obj@meta.data
required <- c("orig.ident", "source", "condition", "annotation", "nCount_RNA", "nFeature_RNA", "percent.mito", "doublet_prediction")
assert_columns(meta, required, "GSE173252 author metadata")

source_map <- c(DD = "Dupuytren", SF = "Skoog", Dermis = "Dermis")
tissue_map <- c(DD = "Dupuytren_fascia", SF = "Skoog_fascia", Dermis = "healthy_dermis")
if (!all(unique(meta$source) %in% names(source_map))) {
  stop("Unexpected source values: ", paste(setdiff(unique(meta$source), names(source_map)), collapse = ", "))
}

standard <- data.frame(
  cell_barcode = rownames(meta),
  donor_id = as.character(meta$orig.ident),
  source = as.character(meta$source),
  condition = unname(source_map[as.character(meta$source)]),
  tissue = unname(tissue_map[as.character(meta$source)]),
  cell_type = as.character(meta$annotation),
  author_cluster = as.character(meta$seurat_clusters),
  nCount_RNA = as.numeric(meta$nCount_RNA),
  nFeature_RNA = as.numeric(meta$nFeature_RNA),
  percent_mito = as.numeric(meta$percent.mito),
  author_doublet = as.logical(meta$doublet_prediction),
  stringsAsFactors = FALSE,
  row.names = rownames(meta)
)

if (!identical(rownames(counts), NULL) && !setequal(colnames(counts), standard$cell_barcode)) {
  stop("RNA count cell barcodes do not match metadata")
}

# A donor-specific robust QC audit. The author object has already undergone its
# published QC; we remove author-flagged doublets and only flag—not silently
# remove—additional MAD outliers for sensitivity reporting.
standard$qc_low_complexity <- FALSE
standard$qc_high_mito <- FALSE
for (donor in unique(standard$donor_id)) {
  index <- which(standard$donor_id == donor)
  med_feature <- median(standard$nFeature_RNA[index], na.rm = TRUE)
  mad_feature <- mad(standard$nFeature_RNA[index], constant = 1, na.rm = TRUE)
  med_mito <- median(standard$percent_mito[index], na.rm = TRUE)
  mad_mito <- mad(standard$percent_mito[index], constant = 1, na.rm = TRUE)
  standard$qc_low_complexity[index] <- standard$nFeature_RNA[index] < max(200, med_feature - 3 * mad_feature)
  standard$qc_high_mito[index] <- standard$percent_mito[index] > med_mito + 3 * mad_mito
}
standard$analysis_keep <- !standard$author_doublet & !standard$qc_low_complexity & !standard$qc_high_mito
write_audit_tsv(standard, "GSE173252_standardized_cell_metadata.tsv")

flow <- data.frame(
  step = c("author object", "remove author-flagged doublets", "remove donor-specific QC flags"),
  n_cells = c(nrow(standard), sum(!standard$author_doublet), sum(standard$analysis_keep))
)
write_audit_tsv(flow, "GSE173252_qc_flow.tsv")
message("Standardized GSE173252 metadata; retained ", sum(standard$analysis_keep), " / ", nrow(standard), " cells")

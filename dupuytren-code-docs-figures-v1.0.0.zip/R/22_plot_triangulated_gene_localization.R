#!/usr/bin/env Rscript
source("R/utils.R")
dir.create("results/figures", recursive = TRUE, showWarnings = FALSE)
x <- data.table::fread("results/tables/triangulated_gene_mesenchymal_state_summary.tsv")
# Do not render cells/states represented by fewer than 20 recovered cells.
x <- x[n_cells >= 20]
state_order <- c("Resident_fibroblast_CXCL14_SFRP2_like", "Resident_fibroblast_COL14A1_like",
  "Resident_fibroblast_CXCL14_hi_like", "Pericyte_RGS5_MCAM_like", "Pathogenic_PDPN_FAP_like")
x[, mesenchyme_state := factor(mesenchyme_state, levels = state_order)]
x[, condition := factor(condition, levels = c("Skoog", "Dupuytren", "Dermis"))]
p <- ggplot2::ggplot(x, ggplot2::aes(x = condition, y = mesenchyme_state, fill = mean_of_donor_means)) +
  ggplot2::geom_tile(colour = "white") +
  ggplot2::facet_wrap(~ gene, nrow = 1) +
  ggplot2::scale_fill_viridis_c(name = "Mean donor\nlog1p(CP10k)") +
  ggplot2::labs(x = NULL, y = NULL, title = "Exploratory directional-triangulation gene localization") +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(panel.grid = ggplot2::element_blank(), axis.text.x = ggplot2::element_text(angle = 35, hjust = 1))
ggplot2::ggsave("results/figures/triangulated_gene_localization.png", p, width = 11, height = 4.6, dpi = 320)
message("Wrote triangulated-gene localization figure")

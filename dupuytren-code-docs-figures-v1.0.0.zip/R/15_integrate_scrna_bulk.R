#!/usr/bin/env Rscript
source("R/utils.R")

# Bulk expression is validation of direction/pathway coherence only: it cannot
# identify the cellular source of a signal.
bulk <- data.table::fread("results/tables/bulk_GSE75152_de.tsv")
scrna <- data.table::fread("results/tables/scrna_pseudobulk_de.tsv")
mes <- scrna[analysis_level == "broad_cell_type" & analysis_state == "Mesenchyme",
  .(gene, scrna_logFC = logFC, scrna_PValue = PValue, scrna_FDR = FDR_within_state)]
merged <- merge(mes, bulk[, .(gene, bulk_logFC = logFC, bulk_PValue = P.Value, bulk_FDR = adj.P.Val)], by = "gene")
merged[, direction_concordant := sign(scrna_logFC) == sign(bulk_logFC)]
merged[, both_fdr_lt_005 := scrna_FDR < 0.05 & bulk_FDR < 0.05]
write_audit_tsv(merged, "scrna_bulk_mesenchyme_gene_concordance.tsv")

expr <- data.table::fread("results/tables/GSE75152_expression.tsv")
meta <- data.table::fread("results/tables/GSE75152_samples.tsv")
mat <- as.matrix(expr[, -"gene"])
rownames(mat) <- expr$gene
mat <- mat[, meta$sample_id, drop = FALSE]
z <- t(scale(t(mat)))
z[is.na(z)] <- 0

read_gmt <- function(path) {
  pieces <- strsplit(readLines(path, warn = FALSE), "\t", fixed = TRUE)
  stats::setNames(lapply(pieces, function(x) unique(x[-c(1, 2)])), vapply(pieces, `[[`, character(1), 1))
}
sets <- read_gmt("config/gene_sets.gmt")
score_list <- lapply(sets, function(gs) {
  available <- intersect(gs, rownames(z))
  if (length(available) < 5L) return(rep(NA_real_, ncol(z)))
  colMeans(z[available, , drop = FALSE])
})
scores <- do.call(cbind, score_list)
rownames(scores) <- colnames(mat)
scores <- scores[meta$sample_id, , drop = FALSE]
design <- model.matrix(~ 0 + condition, meta)
fit <- limma::lmFit(t(scores), design)
contrast <- limma::makeContrasts(conditionDupuytren - conditionControl, levels = design)
fit <- limma::eBayes(limma::contrasts.fit(fit, contrast), trend = TRUE, robust = TRUE)
program_de <- limma::topTable(fit, number = Inf, sort.by = "P")
program_de$program <- rownames(program_de)
program_de$n_mapped_genes <- vapply(sets[program_de$program], function(gs) length(intersect(gs, rownames(z))), integer(1))
write_audit_tsv(data.frame(sample_id = rownames(scores), condition = meta$condition, scores, check.names = FALSE),
  "bulk_GSE75152_program_scores.tsv")
write_audit_tsv(program_de, "bulk_GSE75152_program_de.tsv")

summary <- data.frame(
  metric = c("shared_genes", "both_FDR_lt_005", "concordant_among_both_FDR", "concordance_fraction_among_both_FDR"),
  value = c(nrow(merged), sum(merged$both_fdr_lt_005),
    sum(merged$direction_concordant & merged$both_fdr_lt_005),
    ifelse(sum(merged$both_fdr_lt_005) == 0, NA_real_, mean(merged$direction_concordant[merged$both_fdr_lt_005])))
)
write_audit_tsv(summary, "scrna_bulk_integration_summary.tsv")
message("Integrated ", nrow(merged), " shared genes between mesenchymal pseudo-bulk and bulk validation")

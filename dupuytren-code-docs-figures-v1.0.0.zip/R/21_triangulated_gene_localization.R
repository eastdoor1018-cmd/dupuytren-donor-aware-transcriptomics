#!/usr/bin/env Rscript
source("R/utils.R")

# These genes satisfy a deliberately stringent *directional* rule across the
# available discovery/validation data. This script maps their expression; it
# does not imply genetic causality or target validity.
tri <- data.table::fread("results/tables/scrna_two_bulk_directional_triangulation.tsv")
genes <- tri[triangulated_directional_support == TRUE, gene]
if (!length(genes)) stop("No directional triangulation genes available")
meta <- data.table::fread("results/tables/scrna_analysis_cell_metadata.tsv")
meta <- meta[condition %in% c("Dupuytren", "Skoog", "Dermis")]
obj <- gse173252_author_object()
counts <- gse173252_raw_counts(obj)
cells <- intersect(colnames(counts), meta$cell_barcode)
meta <- meta[match(cells, cell_barcode)]
counts <- counts[, cells, drop = FALSE]
if (!identical(meta$cell_barcode, colnames(counts))) stop("Cell ordering failed")

features <- intersect(genes, rownames(counts))
if (length(features) != length(genes)) stop("Triangulated gene absent from count matrix")
library_size <- Matrix::colSums(counts)
expr <- counts[features, , drop = FALSE]
log_norm <- log1p(t(t(expr) / pmax(library_size, 1)) * 10000)
rows <- lapply(features, function(gene) {
  value <- as.numeric(log_norm[gene, ])
  temp <- data.table::copy(meta)
  temp[, expression := value]
  temp[, .(mean_log1p_cpm = mean(expression), fraction_detected = mean(expression > 0), n_cells = .N),
    by = .(donor_id, condition, cell_type, mesenchyme_state)][, gene := gene]
})
out <- data.table::rbindlist(rows)
write_audit_tsv(out, "triangulated_gene_cell_state_localization.tsv")

mes <- out[cell_type == "Mesenchyme"]
summary <- mes[, .(
  mean_of_donor_means = mean(mean_log1p_cpm),
  mean_fraction_detected = mean(fraction_detected),
  donors = data.table::uniqueN(donor_id), n_cells = sum(n_cells)
), by = .(gene, condition, mesenchyme_state)]
write_audit_tsv(summary, "triangulated_gene_mesenchymal_state_summary.tsv")
message("Localized ", length(genes), " directionally triangulated genes")

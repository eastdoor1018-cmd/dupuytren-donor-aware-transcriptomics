#!/usr/bin/env Rscript
source("R/utils.R")

# GSE75152 is an Illumina HumanWG-6 v3 expression microarray. Raw IDAT files
# and the matching BGX manifest are used rather than relying on the processed
# GEO matrix, whose negative values make a naive log transformation invalid.
raw_dir <- "data/raw/geo/GSE75152"
dir.create(raw_dir, recursive = TRUE, showWarnings = FALSE)
gse <- GEOquery::getGEO("GSE75152", GSEMatrix = TRUE, getGPL = FALSE, destdir = raw_dir)[[1]]
if (Biobase::annotation(gse) != "GPL6884") stop("Unexpected platform: ", Biobase::annotation(gse))
if (ncol(Biobase::exprs(gse)) != 24L) stop("Unexpected GSE75152 sample count")
idat_dir <- file.path(raw_dir, "idat")
idat_files <- sort(list.files(idat_dir, pattern = "\\.idat$", full.names = TRUE))
bgx_file <- file.path(raw_dir, "HumanWG-6_V3_0_R0_11282955_A.bgx.gz")
if (length(idat_files) != 24L || !file.exists(bgx_file)) {
  stop("Raw IDAT/BGX files are missing. Download GSE75152_RAW.tar and GPL6884 BGX before preprocessing.")
}
raw_idat <- limma::read.idat(idat_files, bgx_file, verbose = FALSE)
norm_idat <- limma::neqc(raw_idat)
if (ncol(norm_idat$E) != 24L || nrow(norm_idat$E) != 48804L) stop("Unexpected neqc output dimensions")

probe_map <- data.frame(probe_id = as.character(norm_idat$genes$Array_Address_Id), gene = trimws(norm_idat$genes$Symbol), stringsAsFactors = FALSE)
probe_map$gene <- sub("[;,].*$", "", probe_map$gene)
probe_map <- probe_map[!is.na(probe_map$gene) & nzchar(probe_map$gene) & probe_map$probe_id %in% rownames(norm_idat$E), ]
probe_map <- probe_map[!duplicated(probe_map$probe_id), ]
mat <- norm_idat$E[probe_map$probe_id, , drop = FALSE]
rownames(mat) <- probe_map$gene

# One probe per HGNC symbol avoids treating technical probes as independent
# genes. Retain the probe with largest across-sample IQR; ties resolve by probe
# ID so the choice is reproducible.
iqr <- apply(mat, 1, IQR, na.rm = TRUE)
choice <- data.frame(gene = rownames(mat), probe_id = probe_map$probe_id, iqr = iqr, stringsAsFactors = FALSE)
choice <- choice[order(choice$gene, -choice$iqr, choice$probe_id), ]
choice <- choice[!duplicated(choice$gene), ]
mat <- mat[match(choice$gene, rownames(mat)), , drop = FALSE]
rownames(mat) <- choice$gene

pd <- Biobase::pData(gse)
condition <- ifelse(grepl("^patient_", pd$title, ignore.case = TRUE), "Dupuytren",
  ifelse(grepl("^control_", pd$title, ignore.case = TRUE), "Control", NA_character_))
if (anyNA(condition) || sum(condition == "Dupuytren") != 12L || sum(condition == "Control") != 12L) {
  stop("Could not recover the expected 12 Dupuytren and 12 control samples")
}
metadata <- data.frame(sample_id = rownames(pd), condition = condition, title = pd$title,
  sex = sub("^gender: ", "", pd$characteristics_ch1), stringsAsFactors = FALSE)
colnames(mat) <- metadata$sample_id

write_audit_tsv(data.frame(gene = rownames(mat), mat, check.names = FALSE), "GSE75152_expression.tsv")
write_audit_tsv(metadata, "GSE75152_samples.tsv")
write_audit_tsv(data.frame(
  metric = c("raw_idat_features", "regular_probes_after_neqc", "mapped_symbol_probes", "unique_gene_symbols", "samples", "dupuytren_samples", "control_samples"),
  value = c(nrow(raw_idat$E), nrow(norm_idat$E), nrow(probe_map), nrow(mat), ncol(mat), sum(condition == "Dupuytren"), sum(condition == "Control"))
), "GSE75152_preprocessing_audit.tsv")
message("Prepared GSE75152: ", nrow(mat), " unique gene symbols across ", ncol(mat), " samples")

#!/usr/bin/env Rscript
source("R/utils.R")
dir.create("results/figures", recursive = TRUE, showWarnings = FALSE)

composition <- data.table::fread("results/tables/scrna_mesenchyme_state_composition.tsv")
cors <- data.table::fread("results/tables/scrna_md_specificity_correlations.tsv")
de <- data.table::fread("results/tables/scrna_pseudobulk_de.tsv")

condition_order <- c("Skoog", "Dupuytren", "Dermis")
composition[, donor_id := factor(donor_id, levels = unique(donor_id[order(match(condition, condition_order), donor_id)]))]
composition[, condition := factor(condition, levels = condition_order)]
state_labels <- c(
  "Pathogenic_PDPN_FAP_like" = "PDPN/FAP-like state",
  "Resident_fibroblast_CXCL14_SFRP2_like" = "CXCL14/SFRP2-like fibroblast",
  "Resident_fibroblast_COL14A1_like" = "COL14A1-like fibroblast",
  "Resident_fibroblast_CXCL14_hi_like" = "CXCL14-high fibroblast",
  "Pericyte_RGS5_MCAM_like" = "RGS5/MCAM-like pericyte"
)
composition[, state_label := factor(state_labels[mesenchyme_state], levels = rev(unname(state_labels)))]

p_comp <- ggplot2::ggplot(composition, ggplot2::aes(x = donor_id, y = fraction_of_mesenchyme, fill = state_label)) +
  ggplot2::geom_col(width = 0.78, colour = "white", linewidth = 0.18) +
  ggplot2::facet_grid(. ~ condition, scales = "free_x", space = "free_x") +
  ggplot2::scale_y_continuous(labels = scales::percent_format(accuracy = 1), expand = c(0, 0)) +
  ggplot2::labs(x = NULL, y = "Fraction of mesenchymal cells", fill = NULL,
    title = "Donor-level composition of annotated mesenchymal states") +
  ggplot2::theme_classic(base_size = 11) +
  ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1),
    strip.background = ggplot2::element_rect(fill = "grey95", colour = NA), legend.position = "bottom")
ggplot2::ggsave("results/figures/fascia_state_composition.png", p_comp, width = 10, height = 5.5, dpi = 320)

cors[, md_label := sub("_UCell$", "", md_program)]
cors[, control_label := sub("_UCell$", "", control_program)]
p_cor <- ggplot2::ggplot(cors[!is.na(rho)], ggplot2::aes(x = control_label, y = md_label, fill = rho)) +
  ggplot2::geom_tile(colour = "white") +
  ggplot2::geom_text(ggplot2::aes(label = sprintf("%.3f", rho)), size = 4) +
  ggplot2::scale_fill_gradient2(low = "#2166ac", mid = "white", high = "#b2182b", midpoint = 0, limits = c(-1, 1)) +
  ggplot2::labs(x = NULL, y = NULL, fill = "Spearman rho", title = "MD score is not separable from core fibrosis programs") +
  ggplot2::theme_minimal(base_size = 11) +
  ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 30, hjust = 1), panel.grid = ggplot2::element_blank())
ggplot2::ggsave("results/figures/md_program_collinearity.png", p_cor, width = 8, height = 3.4, dpi = 320)

mes_de <- de[analysis_level == "broad_cell_type" & analysis_state == "Mesenchyme"]
mes_de[, neg_log10_fdr := -log10(pmax(FDR_within_state, .Machine$double.xmin))]
top <- mes_de[order(FDR_within_state)][1:20]
top[, gene := factor(gene, levels = gene[order(logFC)])]
p_de <- ggplot2::ggplot(top, ggplot2::aes(x = logFC, y = gene, colour = logFC > 0)) +
  ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "grey55") +
  ggplot2::geom_point(size = 2.8) +
  ggplot2::scale_colour_manual(values = c("#2c7fb8", "#d95f0e"), guide = "none") +
  ggplot2::labs(x = "Dupuytren vs Skoog log2 fold change", y = NULL,
    title = "Top donor-level mesenchymal pseudo-bulk differences") +
  ggplot2::theme_classic(base_size = 11)
ggplot2::ggsave("results/figures/mesenchyme_pseudobulk_top_de.png", p_de, width = 7.5, height = 6.2, dpi = 320)

message("Wrote single-cell result figures")

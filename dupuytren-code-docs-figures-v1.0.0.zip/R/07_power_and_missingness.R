#!/usr/bin/env Rscript
source("R/utils.R")
cfg <- read_analysis_config()

clump_path <- Sys.getenv("POWER_CLUMP_PATH", unset = "results/tables/cadby_clumping_audit.tsv")
coverage_path <- Sys.getenv("POWER_COVERAGE_PATH", unset = "results/tables/mr_instrument_coverage.tsv")
mr_path <- Sys.getenv("POWER_MR_PATH", unset = "results/tables/mr_primary.tsv")
output_prefix <- Sys.getenv("POWER_OUTPUT_PREFIX", unset = "")
clump <- data.table::fread(clump_path)
coverage <- data.table::fread(coverage_path)
mr <- data.table::fread(mr_path)
assert_columns(clump, c("lipid", "lipid_class", "SNP", "clump_remove_reason"), "clump audit")

clump[, ld_status := data.table::fcase(
  clump_remove_reason == "absent_from_EUR_LD_reference", "absent_reference",
  clump_remove_reason == "LD_with_stronger_instrument", "removed_LD",
  default = "kept"
)]
missing_by_class <- clump[, .(
  n_rows = .N,
  n_absent_reference = sum(ld_status == "absent_reference"),
  n_removed_ld = sum(ld_status == "removed_LD"),
  n_kept = sum(ld_status == "kept"),
  absent_reference_fraction = mean(ld_status == "absent_reference")
), by = lipid_class]
data.table::setorder(missing_by_class, -absent_reference_fraction)
write_audit_tsv(missing_by_class, paste0(output_prefix, "instrument_missingness_by_lipid_class.tsv"))

# Global heterogeneity test for reference-panel availability across lipid classes.
availability <- table(clump$lipid_class, clump$ld_status == "absent_reference")
set.seed(cfg$project$random_seed)
chi <- suppressWarnings(chisq.test(availability, simulate.p.value = TRUE, B = 10000))
write_audit_tsv(data.frame(
  test = "simulated chi-square: lipid class x absent from EUR reference",
  statistic = unname(chi$statistic), p = chi$p.value, simulations = 10000
), paste0(output_prefix, "instrument_missingness_global_test.tsv"))

coverage <- merge(coverage, unique(clump[, .(lipid, lipid_class)]), by = "lipid", all.x = TRUE)
coverage_by_class <- coverage[, .(
  n_lipids = .N,
  n_estimable = sum(status == "estimable"),
  n_no_outcome_match = sum(status == "no_outcome_match"),
  n_all_removed_harmonization = sum(status == "all_removed_harmonization"),
  estimable_fraction = mean(status == "estimable")
), by = lipid_class]
data.table::setorder(coverage_by_class, estimable_fraction)
write_audit_tsv(coverage_by_class, paste0(output_prefix, "mr_coverage_by_lipid_class.tsv"))

# Minimum detectable causal effect based on each primary estimate's achieved SE.
# This does not claim prospective power under a different instrument set.
z_alpha_fdr <- qnorm(1 - (0.05 / nrow(mr)) / 2)
z_alpha_nominal <- qnorm(1 - 0.05 / 2)
for (target_power in c(0.80, 0.90)) {
  suffix <- as.character(round(target_power * 100))
  z_power <- qnorm(target_power)
  mr[[paste0("mde_beta_fdr_power", suffix)]] <- (z_alpha_fdr + z_power) * mr$se
  mr[[paste0("mde_or_fdr_power", suffix)]] <- exp(mr[[paste0("mde_beta_fdr_power", suffix)]])
  mr[[paste0("mde_beta_nominal_power", suffix)]] <- (z_alpha_nominal + z_power) * mr$se
  mr[[paste0("mde_or_nominal_power", suffix)]] <- exp(mr[[paste0("mde_beta_nominal_power", suffix)]])
}
write_audit_tsv(mr, paste0(output_prefix, "mr_minimum_detectable_effects.tsv"))

power_summary <- data.frame(
  metric = c(
    "median detectable OR per 1-SD lipid at 80% power, FWER alpha",
    "25th percentile detectable OR per 1-SD lipid at 80% power, FWER alpha",
    "75th percentile detectable OR per 1-SD lipid at 80% power, FWER alpha"
  ),
  value = c(
    median(mr$mde_or_fdr_power80, na.rm = TRUE),
    unname(quantile(mr$mde_or_fdr_power80, 0.25, na.rm = TRUE)),
    unname(quantile(mr$mde_or_fdr_power80, 0.75, na.rm = TRUE))
  ),
  note = "Absolute OR boundary; reciprocal gives protective-effect boundary"
)
write_audit_tsv(power_summary, paste0(output_prefix, "mr_power_summary.tsv"))

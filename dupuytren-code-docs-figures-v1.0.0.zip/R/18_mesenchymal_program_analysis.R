#!/usr/bin/env Rscript
source("R/utils.R")

# UCell scores are aggregated to donor medians before disease testing. This is
# deliberately a small-sample program-level analysis, not a cell-level test.
meta <- data.table::fread("results/tables/scrna_analysis_cell_metadata.tsv")
scores <- data.table::fread("results/tables/scrna_cell_program_scores.tsv")
dat <- merge(meta, scores, by = "cell_barcode", sort = FALSE)
dat <- dat[cell_type == "Mesenchyme" & condition %in% c("Dupuytren", "Skoog")]
score_cols <- grep("_UCell$", names(dat), value = TRUE)
donor <- dat[, lapply(.SD, median, na.rm = TRUE), by = .(donor_id, condition), .SDcols = score_cols]
mat <- t(as.matrix(donor[, ..score_cols]))
design <- model.matrix(~ 0 + condition, donor)
fit <- limma::lmFit(mat, design)
contrast <- limma::makeContrasts(conditionDupuytren - conditionSkoog, levels = design)
fit <- limma::eBayes(limma::contrasts.fit(fit, contrast), trend = TRUE, robust = TRUE)
tab <- limma::topTable(fit, number = Inf, sort.by = "P")
tab$program <- rownames(tab)
tab$n_dupuytren_donors <- sum(donor$condition == "Dupuytren")
tab$n_skoog_donors <- sum(donor$condition == "Skoog")
write_audit_tsv(donor, "scrna_mesenchymal_program_donor_medians.tsv")
write_audit_tsv(tab, "scrna_mesenchymal_program_de.tsv")

# The three lipid-metabolism scores were fixed before looking at disease effects.
lipid_programs <- c("SPHINGOLIPID_METABOLISM_CORE_UCell", "GLYCEROPHOSPHOLIPID_METABOLISM_CORE_UCell", "FATTY_ACID_OXIDATION_CORE_UCell", "CHOLESTEROL_HOMEOSTASIS_CORE_UCell")
write_audit_tsv(tab[match(lipid_programs, tab$program), ], "scrna_mesenchymal_lipid_program_de.tsv")
message("Completed donor-level mesenchymal program analysis")

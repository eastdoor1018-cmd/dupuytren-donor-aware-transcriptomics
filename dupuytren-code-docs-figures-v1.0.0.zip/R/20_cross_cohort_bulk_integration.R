#!/usr/bin/env Rscript
source("R/utils.R")

# The two bulk platforms have different expression scales; combine signed
# evidence, not raw log-fold changes. GSE75152 is the larger cohort (n=24),
# while GSE31356 is a three-pair directional replication.
large <- data.table::fread("results/tables/bulk_GSE75152_de.tsv")
paired <- data.table::fread("results/tables/bulk_GSE31356_paired_de.tsv")
bulk <- merge(
  large[, .(gene, logFC_GSE75152 = logFC, P_GSE75152 = P.Value, FDR_GSE75152 = adj.P.Val)],
  paired[, .(gene, logFC_GSE31356 = logFC, P_GSE31356 = P.Value, FDR_GSE31356 = adj.P.Val)], by = "gene"
)
signed_z <- function(p, effect) sign(effect) * stats::qnorm(pmax(p, .Machine$double.xmin) / 2, lower.tail = FALSE)
bulk[, z_GSE75152 := signed_z(P_GSE75152, logFC_GSE75152)]
bulk[, z_GSE31356 := signed_z(P_GSE31356, logFC_GSE31356)]
bulk[, stouffer_z := (sqrt(24) * z_GSE75152 + sqrt(6) * z_GSE31356) / sqrt(30)]
bulk[, meta_P := 2 * pnorm(abs(stouffer_z), lower.tail = FALSE)]
bulk[, meta_FDR := p.adjust(meta_P, method = "BH")]
bulk[, bulk_direction_concordant := sign(logFC_GSE75152) == sign(logFC_GSE31356)]
bulk[, paired_nominal_same_direction := bulk_direction_concordant & P_GSE31356 < 0.05]
write_audit_tsv(bulk, "bulk_cross_cohort_signed_evidence.tsv")

sc <- data.table::fread("results/tables/scrna_pseudobulk_de.tsv")
sc <- sc[analysis_level == "broad_cell_type" & analysis_state == "Mesenchyme",
  .(gene, scrna_logFC = logFC, scrna_FDR = FDR_within_state)]
tri <- merge(sc, bulk, by = "gene")
tri[, sc_vs_large_concordant := sign(scrna_logFC) == sign(logFC_GSE75152)]
tri[, sc_vs_paired_concordant := sign(scrna_logFC) == sign(logFC_GSE31356)]
tri[, three_dataset_direction_concordant := sc_vs_large_concordant & sc_vs_paired_concordant]
tri[, triangulated_directional_support := scrna_FDR < 0.05 & FDR_GSE75152 < 0.05 &
  P_GSE31356 < 0.05 & three_dataset_direction_concordant]
write_audit_tsv(tri, "scrna_two_bulk_directional_triangulation.tsv")
summary <- data.frame(
  metric = c("shared_bulk_genes", "bulk_direction_concordant", "paired_nominal_same_direction",
    "shared_three_dataset_genes", "triangulated_directional_support"),
  value = c(nrow(bulk), sum(bulk$bulk_direction_concordant), sum(bulk$paired_nominal_same_direction),
    nrow(tri), sum(tri$triangulated_directional_support))
)
write_audit_tsv(summary, "cross_cohort_integration_summary.tsv")
message("Completed cross-cohort signed evidence integration")

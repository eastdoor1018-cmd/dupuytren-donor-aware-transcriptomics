#!/usr/bin/env Rscript
source("R/utils.R")
dir.create("results/figures", recursive = TRUE, showWarnings = FALSE)

boxes <- data.frame(
  x = c(1.5, 1.5, 4.5, 4.5, 4.5, 4.5, 7.5, 7.5),
  y = c(5.6, 2.2, 6.5, 4.6, 2.75, 0.9, 5.4, 2.2),
  fill = c("genetic", "genetic", "single_cell", "bulk", "bulk", "bulk", "result", "boundary"),
  label = c(
    "Cadby 2022 lipid MR\n470 estimable lipids\nNo BH-FDR signal",
    "Landstra 2026 lipid MR\n444 estimable lipids\nNo BH-FDR signal",
    "GSE173252 single-cell\n3 Dupuytren + 3 Skoog fascia\nDonor-level pseudo-bulk",
    "GSE75152 bulk tissue\n12 Dupuytren + 12 control\nIndependent direction check",
    "GSE31356 paired tissue\n3 Dupuytren/non-diseased pairs\nDirectional check only",
    "Zenodo 14017529 NGS\n26 Dupuytren + 17 control\nRestricted direction check",
    "Supported result\nPathological state localization\nRobust mixed-mesenchymal signature",
    "Evidence boundaries\nNo MD headline\nNo causal lipid / target claim"
  ), stringsAsFactors = FALSE
)
cols <- c(genetic = "#d9eaf7", single_cell = "#dff1e4", bulk = "#fff0c9", result = "#d9ead3", boundary = "#f7d6d0")
p <- ggplot2::ggplot() +
  ggplot2::geom_rect(data = boxes, ggplot2::aes(xmin = x - 1.15, xmax = x + 1.15, ymin = y - .75, ymax = y + .75, fill = fill),
    colour = "grey35", linewidth = .45, show.legend = FALSE) +
  ggplot2::geom_text(data = boxes, ggplot2::aes(x = x, y = y, label = label), size = 3.4, lineheight = .92) +
  ggplot2::scale_fill_manual(values = cols) +
  ggplot2::annotate("segment", x = 5.65, xend = 6.3, y = 6.2, yend = 5.55, arrow = grid::arrow(length = grid::unit(0.16, "cm"))) +
  ggplot2::annotate("segment", x = 5.65, xend = 6.3, y = 4.3, yend = 5.15, arrow = grid::arrow(length = grid::unit(0.16, "cm"))) +
  ggplot2::annotate("segment", x = 5.65, xend = 6.3, y = 2.75, yend = 4.95, arrow = grid::arrow(length = grid::unit(0.16, "cm"))) +
  ggplot2::annotate("segment", x = 5.65, xend = 6.3, y = 0.9, yend = 4.95, arrow = grid::arrow(length = grid::unit(0.16, "cm"))) +
  ggplot2::annotate("segment", x = 2.65, xend = 6.3, y = 5.6, yend = 2.65, linetype = 2, arrow = grid::arrow(length = grid::unit(0.16, "cm"))) +
  ggplot2::annotate("segment", x = 2.65, xend = 6.3, y = 2.2, yend = 2.2, linetype = 2, arrow = grid::arrow(length = grid::unit(0.16, "cm"))) +
  ggplot2::coord_cartesian(xlim = c(0, 9), ylim = c(0, 7.7), expand = FALSE) +
  ggplot2::labs(title = "Evidence-constrained public transcriptomic study design") +
  ggplot2::theme_void(base_size = 12) +
  ggplot2::theme(plot.title = ggplot2::element_text(hjust = .5, face = "bold"),
    plot.background = ggplot2::element_rect(fill = "white", colour = NA),
    panel.background = ggplot2::element_rect(fill = "white", colour = NA))
ggplot2::ggsave("results/figures/study_design_evidence_flow.png", p, width = 11.5, height = 7.2, dpi = 320)
message("Wrote study-design evidence flow figure")

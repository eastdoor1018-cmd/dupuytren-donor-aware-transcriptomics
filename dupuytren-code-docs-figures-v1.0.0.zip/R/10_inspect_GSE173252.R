#!/usr/bin/env Rscript
source("R/utils.R")

input <- Sys.getenv(
  "GSE173252_RDS_GZ",
  unset = "data/raw/geo/GSE173252/GSE173252_dd.rds.gz"
)
if (!file.exists(input)) stop("Missing GSE173252 RDS: ", input)

obj <- gse173252_author_object(input)
meta <- obj@meta.data

schema <- data.frame(
  column = colnames(meta),
  class = vapply(meta, function(x) paste(class(x), collapse = ";"), character(1)),
  n_unique = vapply(meta, function(x) length(unique(x)), integer(1)),
  example_values = vapply(meta, function(x) paste(utils::head(unique(as.character(x)), 8), collapse = " | "), character(1)),
  row.names = NULL
)
write_audit_tsv(schema, "GSE173252_metadata_schema.tsv")

assay_rows <- lapply(names(obj@assays), function(assay_name) {
  assay <- obj@assays[[assay_name]]
  slots <- slotNames(assay)
  data.frame(assay = assay_name, slots = paste(slots, collapse = " | "), row.names = NULL)
})
write_audit_tsv(data.table::rbindlist(assay_rows), "GSE173252_assay_inventory.tsv")

# This discovery-only inspection does not modify expression values, annotations,
# or create inferential results. It documents the exact author object before we
# map metadata to frozen donor/condition/cell-state fields.
counts <- gse173252_raw_counts(obj)
message("Inspected ", ncol(counts), " cells and ", nrow(counts), " RNA features across assays: ",
  paste(names(obj@assays), collapse = ", "))

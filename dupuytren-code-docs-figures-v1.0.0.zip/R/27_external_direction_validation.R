#!/usr/bin/env Rscript
source("R/utils.R")

# This is not a third genome-wide discovery scan. The external workbook stores
# only genes selected by its original authors. We therefore restrict inference
# to direction agreement for signals fixed without looking at this workbook.
external <- data.table::fread("results/tables/bulk_Zenodo14017529_selected_set_de.tsv")
sc <- data.table::fread("results/tables/scrna_pseudobulk_de.tsv")
sc <- sc[analysis_level == "broad_cell_type" & analysis_state == "Mesenchyme",
  .(gene, scrna_logFC = logFC, scrna_FDR = FDR_within_state)]
primary <- data.table::fread("results/tables/scrna_bulk_mesenchyme_gene_concordance.tsv")
primary <- primary[both_fdr_lt_005 == TRUE,
  .(gene, scrna_logFC, scrna_FDR, GSE75152_logFC = bulk_logFC, GSE75152_FDR = bulk_FDR)]

all_sc_overlap <- merge(sc, external[, .(gene, Zenodo_logFC = logFC, Zenodo_P = P.Value,
  Zenodo_selected_set_FDR = adj.P.Val, reported_log2FC)], by = "gene")
all_sc_overlap[, direction_concordant := sign(scrna_logFC) == sign(Zenodo_logFC)]
all_sc_overlap[, external_set_scope := "author_selected_237_gene_set"]

primary_overlap <- merge(primary, external[, .(gene, Zenodo_logFC = logFC, Zenodo_P = P.Value,
  Zenodo_selected_set_FDR = adj.P.Val, reported_log2FC)], by = "gene")
primary_overlap[, direction_concordant_three_sources :=
  sign(scrna_logFC) == sign(GSE75152_logFC) & sign(scrna_logFC) == sign(Zenodo_logFC)]
primary_overlap[, external_set_scope := "author_selected_237_gene_set"]

candidates <- data.table::data.table(gene = c("ALDH3A2", "NOVA1", "RAB33A", "MYO1B"))
candidates <- merge(candidates, external[, .(gene, Zenodo_logFC = logFC, Zenodo_P = P.Value,
  Zenodo_selected_set_FDR = adj.P.Val)], by = "gene", all.x = TRUE)
candidates[, assessable_in_Zenodo_selected_set := !is.na(Zenodo_logFC)]
candidates[, external_set_scope := "author_selected_237_gene_set"]

summary <- data.frame(
  metric = c("sc_FDR_significant_genes_available_in_external_selected_set",
    "sc_external_direction_concordance_fraction", "primary_two_source_FDR_genes_available_in_external_selected_set",
    "three_source_direction_concordance_fraction", "four_exploratory_candidates_assessable"),
  value = c(nrow(all_sc_overlap[scrna_FDR < 0.05]),
    if (nrow(all_sc_overlap[scrna_FDR < 0.05])) mean(all_sc_overlap[scrna_FDR < 0.05, direction_concordant]) else NA_real_, nrow(primary_overlap),
    if (nrow(primary_overlap)) mean(primary_overlap$direction_concordant_three_sources) else NA_real_,
    sum(candidates$assessable_in_Zenodo_selected_set)),
  stringsAsFactors = FALSE
)
write_audit_tsv(all_sc_overlap, "scrna_Zenodo14017529_selected_set_direction.tsv")
write_audit_tsv(primary_overlap, "scrna_GSE75152_Zenodo14017529_direction.tsv")
write_audit_tsv(candidates, "exploratory_candidates_Zenodo14017529_availability.tsv")
write_audit_tsv(summary, "Zenodo14017529_external_direction_summary.tsv")
message("Completed restricted external direction check for ", nrow(primary_overlap), " primary two-source genes")

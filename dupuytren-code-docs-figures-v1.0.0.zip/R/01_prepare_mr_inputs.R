#!/usr/bin/env Rscript
source("R/utils.R")
cfg <- read_analysis_config()

input_candidates <- c(
  "data/derived/cadby_2022_supplementary_data_6.tsv",
  "data/derived/cadby_2022_instruments.tsv"
)
input <- input_candidates[file.exists(input_candidates)][1]
if (is.na(input)) {
  stop("No parsed Cadby instrument table. Run: python3 scripts/download_public_data.py --tier bootstrap")
}

dat <- data.table::fread(input, na.strings = c("", "NA", "N/A"))
aliases <- list(
  SNP = c("SNP", "snp", "rsid", "variant", "variant_id"),
  lipid = c("lipid", "lipid_species", "trait", "phenotype"),
  beta = c("beta", "effect", "estimate"),
  se = c("se", "standard_error", "stderr"),
  pval = c("pval", "p_value", "p", "P"),
  effect_allele = c("effect_allele", "EA", "A1", "allele1"),
  other_allele = c("other_allele", "OA", "A2", "allele2")
)

for (canonical in names(aliases)) {
  hit <- intersect(aliases[[canonical]], names(dat))
  if (!canonical %in% names(dat) && length(hit)) data.table::setnames(dat, hit[1], canonical)
}
assert_columns(dat, c("SNP", "lipid", "beta", "se", "pval"), "Cadby instruments")

dat[, f_statistic := f_statistic(beta, se)]
dat[, eligible_p := pval < cfg$mr$instrument_p]
dat[, eligible_f := f_statistic > cfg$mr$min_f_statistic]
dat[, instrument_keep := eligible_p & eligible_f]

write_audit_tsv(dat, "cadby_instrument_audit.tsv")
preclump <- dat[instrument_keep == TRUE & !is.na(SNP) & nzchar(SNP)]
data.table::fwrite(preclump, "data/derived/mr_exposure_instruments_preclump.tsv", sep = "\t", na = "NA")

ld_prefix <- Sys.getenv(cfg$paths$ld_reference_env, unset = "")
plink_bin <- Sys.getenv(cfg$paths$plink_binary_env, unset = Sys.which("plink"))
if (!nzchar(ld_prefix) || !all(file.exists(paste0(ld_prefix, c(".bed", ".bim", ".fam"))))) {
  stop(
    "Pre-clump table was written, but the local European LD reference is missing. ",
    "Set ", cfg$paths$ld_reference_env, " to the bed/bim/fam prefix; see docs/R_SETUP.md"
  )
}
if (!nzchar(plink_bin) || !file.exists(plink_bin)) {
  stop("PLINK is missing. Set ", cfg$paths$plink_binary_env, " to the executable")
}

# Calculate LD once for all unique instruments, then clump separately within each
# lipid. Calling PLINK once per lipid would repeatedly load the 1 GB reference.
reference_ids <- data.table::fread(
  paste0(ld_prefix, ".bim"), select = 2L, header = FALSE,
  col.names = "SNP", colClasses = "character", showProgress = FALSE
)$SNP
preclump[, in_ld_reference := SNP %in% reference_ids]
rm(reference_ids)

extract_file <- tempfile("dupuytren_variants_", fileext = ".txt")
ld_prefix_out <- tempfile("dupuytren_ld_")
writeLines(unique(preclump[in_ld_reference == TRUE]$SNP), extract_file)
plink_args <- c(
  "--bfile", ld_prefix, "--extract", extract_file, "--r2", "gz",
  "--ld-window-kb", as.character(cfg$mr$clump_kb),
  "--ld-window", "999999", "--ld-window-r2", "0",
  "--out", ld_prefix_out
)
status <- system2(plink_bin, plink_args, stdout = TRUE, stderr = TRUE)
if (!file.exists(paste0(ld_prefix_out, ".ld.gz"))) {
  stop("PLINK LD calculation failed:\n", paste(status, collapse = "\n"))
}
ld <- data.table::fread(paste0(ld_prefix_out, ".ld.gz"), showProgress = FALSE)
assert_columns(ld, c("SNP_A", "SNP_B", "R2"), "PLINK LD output")
ld <- ld[R2 >= cfg$mr$clump_r2]

adjacency <- new.env(hash = TRUE, parent = emptyenv())
for (i in seq_len(nrow(ld))) {
  a <- ld$SNP_A[[i]]; b <- ld$SNP_B[[i]]
  assign(a, unique(c(if (exists(a, adjacency, inherits = FALSE)) get(a, adjacency) else character(), b)), adjacency)
  assign(b, unique(c(if (exists(b, adjacency, inherits = FALSE)) get(b, adjacency) else character(), a)), adjacency)
}

clump_one <- function(d) {
  data.table::setorder(d, pval)
  kept <- character()
  reason <- rep(NA_character_, nrow(d))
  for (i in seq_len(nrow(d))) {
    snp <- d$SNP[[i]]
    if (!isTRUE(d$in_ld_reference[[i]])) {
      reason[[i]] <- "absent_from_EUR_LD_reference"
      next
    }
    neighbors <- if (exists(snp, adjacency, inherits = FALSE)) get(snp, adjacency) else character()
    if (any(kept %in% neighbors)) {
      reason[[i]] <- "LD_with_stronger_instrument"
    } else {
      kept <- c(kept, snp)
    }
  }
  d[, clump_remove_reason := reason]
  d
}
clump_audit <- data.table::rbindlist(lapply(split(preclump, preclump$lipid), clump_one), fill = TRUE)
clumped <- clump_audit[is.na(clump_remove_reason)]
write_audit_tsv(clump_audit, "cadby_clumping_audit.tsv")
data.table::fwrite(clumped, "data/derived/mr_exposure_instruments.tsv", sep = "\t", na = "NA")
message("Prepared ", nrow(clumped), " strictly clumped instrument rows across ",
  data.table::uniqueN(clumped$lipid), " lipids")

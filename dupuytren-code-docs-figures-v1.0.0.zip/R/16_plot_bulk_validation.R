#!/usr/bin/env Rscript
source("R/utils.R")
dir.create("results/figures", recursive = TRUE, showWarnings = FALSE)
program_de <- data.table::fread("results/tables/bulk_GSE75152_program_de.tsv")
program_de[, program := factor(program, levels = program[order(logFC)])]
program_de[, significant := adj.P.Val < 0.05]
p <- ggplot2::ggplot(program_de, ggplot2::aes(x = logFC, y = program, colour = significant)) +
  ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "grey55") +
  ggplot2::geom_point(size = 3) +
  ggplot2::scale_colour_manual(values = c(`FALSE` = "grey60", `TRUE` = "#b2182b"), guide = "none") +
  ggplot2::labs(x = "Dupuytren vs control standardized mean-score difference", y = NULL,
    title = "Bulk Dupuytren tissue validates fibrosis and metabolic-program shifts",
    subtitle = "Validation-only: bulk tissue does not assign signals to a cell state") +
  ggplot2::theme_classic(base_size = 11)
ggplot2::ggsave("results/figures/bulk_program_validation.png", p, width = 8.6, height = 5.8, dpi = 320)
message("Wrote bulk validation figure")

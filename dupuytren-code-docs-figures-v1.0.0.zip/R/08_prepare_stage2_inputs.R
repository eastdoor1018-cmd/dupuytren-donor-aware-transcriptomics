#!/usr/bin/env Rscript
source("R/utils.R")
cfg <- read_analysis_config()

input <- "data/derived/landstra_2026_meta_model1_instruments.tsv"
if (!file.exists(input)) {
  stop("Missing parsed Landstra table; run the stage2-bootstrap download first")
}
dat <- data.table::fread(input, na.strings = c("", "NA", "N/A"))
assert_columns(dat, c("SNP", "lipid", "lipid_class", "beta", "pval", "effect_allele"),
  "Landstra Model 1 meta-GWAS instruments")

# Supplementary Data 14 omits SE. For a two-sided additive GWAS test,
# abs(beta) / qnorm(p/2, lower.tail=FALSE) reconstructs it to the precision
# allowed by the published beta and p value.
dat[, se := abs(beta) / stats::qnorm(pval / 2, lower.tail = FALSE)]
dat[, f_statistic := f_statistic(beta, se)]
dat[, eligible_p := pval < cfg$stage2$instrument_p]
dat[, eligible_f := f_statistic > cfg$mr$min_f_statistic]
dat[, instrument_keep := eligible_p & eligible_f & is.finite(se) & se > 0]
write_audit_tsv(dat, "stage2_landstra_instrument_audit.tsv")

preclump <- dat[instrument_keep == TRUE & !is.na(SNP) & grepl("^rs[0-9]+$", SNP)]
data.table::fwrite(preclump,
  "data/derived/stage2_mr_exposure_instruments_preclump.tsv", sep = "\t", na = "NA")

ld_prefix <- Sys.getenv(cfg$paths$ld_reference_env, unset = "")
plink_bin <- Sys.getenv(cfg$paths$plink_binary_env, unset = Sys.which("plink"))
if (!nzchar(ld_prefix) || !all(file.exists(paste0(ld_prefix, c(".bed", ".bim", ".fam"))))) {
  stop("European LD reference is missing; source environment/activate.sh first")
}
if (!nzchar(plink_bin) || !file.exists(plink_bin)) stop("PLINK is missing")

reference_ids <- data.table::fread(
  paste0(ld_prefix, ".bim"), select = 2L, header = FALSE,
  col.names = "SNP", colClasses = "character", showProgress = FALSE
)$SNP
preclump[, in_ld_reference := SNP %in% reference_ids]
rm(reference_ids)

extract_file <- tempfile("stage2_variants_", fileext = ".txt")
ld_prefix_out <- tempfile("stage2_ld_")
writeLines(unique(preclump[in_ld_reference == TRUE]$SNP), extract_file)
plink_args <- c(
  "--bfile", ld_prefix, "--extract", extract_file, "--r2", "gz",
  "--ld-window-kb", as.character(cfg$mr$clump_kb),
  "--ld-window", "999999", "--ld-window-r2", "0", "--out", ld_prefix_out
)
status <- system2(plink_bin, plink_args, stdout = TRUE, stderr = TRUE)
if (!file.exists(paste0(ld_prefix_out, ".ld.gz"))) {
  stop("PLINK LD calculation failed:\n", paste(status, collapse = "\n"))
}
ld <- data.table::fread(paste0(ld_prefix_out, ".ld.gz"), showProgress = FALSE)
assert_columns(ld, c("SNP_A", "SNP_B", "R2"), "PLINK LD output")
ld <- ld[R2 >= cfg$mr$clump_r2]

adjacency <- new.env(hash = TRUE, parent = emptyenv())
for (i in seq_len(nrow(ld))) {
  a <- ld$SNP_A[[i]]; b <- ld$SNP_B[[i]]
  assign(a, unique(c(if (exists(a, adjacency, inherits = FALSE)) get(a, adjacency) else character(), b)), adjacency)
  assign(b, unique(c(if (exists(b, adjacency, inherits = FALSE)) get(b, adjacency) else character(), a)), adjacency)
}

clump_one <- function(d) {
  data.table::setorder(d, pval)
  kept <- character()
  reason <- rep(NA_character_, nrow(d))
  for (i in seq_len(nrow(d))) {
    snp <- d$SNP[[i]]
    if (!isTRUE(d$in_ld_reference[[i]])) {
      reason[[i]] <- "absent_from_EUR_LD_reference"
      next
    }
    neighbors <- if (exists(snp, adjacency, inherits = FALSE)) get(snp, adjacency) else character()
    if (any(kept %in% neighbors)) {
      reason[[i]] <- "LD_with_stronger_instrument"
    } else {
      kept <- c(kept, snp)
    }
  }
  d[, clump_remove_reason := reason]
  d
}

clump_audit <- data.table::rbindlist(lapply(split(preclump, preclump$lipid), clump_one), fill = TRUE)
clumped <- clump_audit[is.na(clump_remove_reason)]
write_audit_tsv(clump_audit, "stage2_landstra_clumping_audit.tsv")
data.table::fwrite(clumped, "data/derived/stage2_mr_exposure_instruments.tsv", sep = "\t", na = "NA")
message("Prepared ", nrow(clumped), " strictly clumped Stage 2 instrument rows across ",
  data.table::uniqueN(clumped$lipid), " lipids")

project_root <- function() {
  root <- normalizePath(getwd(), mustWork = TRUE)
  required <- c("config/analysis.yaml", "config/datasets.tsv")
  if (!all(file.exists(file.path(root, required)))) {
    stop("Run scripts from the project root: ", root)
  }
  root
}

read_analysis_config <- function() {
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Install package 'yaml'")
  yaml::read_yaml(file.path(project_root(), "config", "analysis.yaml"))
}

ensure_dir <- function(path) {
  if (!dir.exists(path)) dir.create(path, recursive = TRUE, showWarnings = FALSE)
  invisible(normalizePath(path, mustWork = TRUE))
}

write_audit_tsv <- function(x, name) {
  if (!requireNamespace("data.table", quietly = TRUE)) stop("Install package 'data.table'")
  out <- file.path(project_root(), "results", "tables", name)
  ensure_dir(dirname(out))
  data.table::fwrite(x, out, sep = "\t", na = "NA")
  message("Wrote ", out)
  invisible(out)
}

assert_columns <- function(x, required, object_name = deparse(substitute(x))) {
  missing <- setdiff(required, names(x))
  if (length(missing)) stop(object_name, " is missing: ", paste(missing, collapse = ", "))
  invisible(TRUE)
}

f_statistic <- function(beta, se) (beta / se)^2

is_palindromic <- function(a1, a2) {
  pair <- paste0(toupper(a1), toupper(a2))
  pair %in% c("AT", "TA", "CG", "GC")
}

harmonize_pair <- function(exposure, outcome, palindromic_maf_max = 0.42) {
  required <- c("SNP", "effect_allele", "other_allele", "beta", "se")
  assert_columns(exposure, required, "exposure")
  assert_columns(outcome, required, "outcome")
  names(exposure)[match(c("effect_allele", "other_allele", "beta", "se"), names(exposure))] <-
    c("effect_allele.exposure", "other_allele.exposure", "beta.exposure", "se.exposure")
  names(outcome)[match(c("effect_allele", "other_allele", "beta", "se"), names(outcome))] <-
    c("effect_allele.outcome", "other_allele.outcome", "beta.outcome", "se.outcome")
  dat <- merge(exposure, outcome, by = "SNP", suffixes = c(".exposure", ".outcome"))

  direct <- toupper(dat$effect_allele.exposure) == toupper(dat$effect_allele.outcome) &
    toupper(dat$other_allele.exposure) == toupper(dat$other_allele.outcome)
  flipped <- toupper(dat$effect_allele.exposure) == toupper(dat$other_allele.outcome) &
    toupper(dat$other_allele.exposure) == toupper(dat$effect_allele.outcome)
  dat$harmonization <- ifelse(direct, "direct", ifelse(flipped, "flipped", "incompatible"))
  dat$beta.outcome[flipped] <- -dat$beta.outcome[flipped]

  pal <- is_palindromic(dat$effect_allele.exposure, dat$other_allele.exposure)
  ambiguous <- rep(FALSE, nrow(dat))
  if ("eaf.exposure" %in% names(dat)) {
    ambiguous <- pal & !is.na(dat$eaf.exposure) &
      dat$eaf.exposure > palindromic_maf_max &
      dat$eaf.exposure < (1 - palindromic_maf_max)
  } else {
    ambiguous <- pal
  }
  dat$remove_reason <- ifelse(dat$harmonization == "incompatible", "allele_mismatch",
    ifelse(ambiguous, "ambiguous_palindrome", NA_character_))
  dat$mr_keep <- is.na(dat$remove_reason)
  dat
}

ivw_random <- function(beta_exposure, beta_outcome, se_outcome) {
  keep <- is.finite(beta_exposure) & is.finite(beta_outcome) & is.finite(se_outcome) &
    beta_exposure != 0 & se_outcome > 0
  x <- beta_exposure[keep]
  y <- beta_outcome[keep]
  sy <- se_outcome[keep]
  k <- length(x)
  if (k < 2) stop("IVW requires at least two valid variants")
  w <- 1 / sy^2
  beta <- sum(w * x * y) / sum(w * x^2)
  q <- sum(w * (y - beta * x)^2)
  phi <- max(1, q / (k - 1))
  se <- sqrt(phi / sum(w * x^2))
  z <- beta / se
  list(beta = beta, se = se, p = 2 * pnorm(abs(z), lower.tail = FALSE),
    q = q, q_df = k - 1, q_p = pchisq(q, df = k - 1, lower.tail = FALSE), n_snp = k)
}

wald_ratio <- function(beta_exposure, beta_outcome, se_exposure, se_outcome) {
  beta <- beta_outcome / beta_exposure
  se <- sqrt((se_outcome^2 / beta_exposure^2) +
    ((beta_outcome^2 * se_exposure^2) / beta_exposure^4))
  list(beta = beta, se = se, p = 2 * pnorm(abs(beta / se), lower.tail = FALSE), n_snp = 1L)
}

read_double_gzip_rds <- function(path) {
  # Some GEO supplementary RDS files are gzip-compressed twice. Stream both
  # layers so no transient multi-GB uncompressed copy is created.
  if (!file.exists(path)) stop("Missing RDS: ", path)
  command <- paste("gzip -dc", shQuote(normalizePath(path)), "| gzip -dc")
  con <- pipe(command, open = "rb")
  on.exit(close(con), add = TRUE)
  readRDS(con)
}

gse173252_author_object <- function(path = "data/raw/geo/GSE173252/GSE173252_dd.rds.gz") {
  obj <- read_double_gzip_rds(path)
  if (!inherits(obj, "Seurat")) stop("Expected a Seurat object in ", path)
  obj
}

gse173252_raw_counts <- function(obj) {
  # Use the source object's RNA count slot directly. This works for the
  # archived Seurat v3 object without relying on a potentially incompatible
  # Seurat v5 layer accessor.
  if (!"RNA" %in% names(obj@assays)) stop("GSE173252 author object has no RNA assay")
  counts <- obj@assays$RNA@counts
  if (!inherits(counts, "dgCMatrix")) stop("RNA counts are not a sparse dgCMatrix")
  counts
}

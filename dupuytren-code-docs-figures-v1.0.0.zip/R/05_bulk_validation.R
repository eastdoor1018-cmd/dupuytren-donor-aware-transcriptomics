#!/usr/bin/env Rscript
source("R/utils.R")

expression_path <- Sys.getenv("GSE75152_EXPRESSION", unset = "results/tables/GSE75152_expression.tsv")
metadata_path <- Sys.getenv("GSE75152_METADATA", unset = "results/tables/GSE75152_samples.tsv")
if (!file.exists(expression_path) || !file.exists(metadata_path)) {
  stop("Missing standardized GSE75152 matrices. Expected expression genes x samples and metadata with sample_id/condition.")
}
expr <- data.table::fread(expression_path)
meta <- data.table::fread(metadata_path)
assert_columns(expr, "gene", "bulk expression")
assert_columns(meta, c("sample_id", "condition"), "bulk metadata")
mat <- as.matrix(expr[, -"gene"])
rownames(mat) <- expr$gene
if (!all(meta$sample_id %in% colnames(mat))) stop("Bulk metadata and expression sample IDs do not match")
mat <- mat[, meta$sample_id, drop = FALSE]
design <- model.matrix(~ 0 + condition, meta)
fit <- limma::lmFit(mat, design)
contrast <- limma::makeContrasts(conditionDupuytren - conditionControl, levels = design)
fit <- limma::eBayes(limma::contrasts.fit(fit, contrast), trend = TRUE, robust = TRUE)
tab <- limma::topTable(fit, number = Inf, sort.by = "P")
tab$gene <- rownames(tab)
write_audit_tsv(tab, "bulk_GSE75152_de.tsv")

#!/usr/bin/env Rscript
source("R/utils.R")
cfg <- read_analysis_config()

paths <- c(
  mr = "results/tables/mr_primary.tsv",
  replication = "results/tables/mr_replication.tsv",
  coloc = "results/tables/colocalization_primary.tsv"
)
missing <- paths[!file.exists(paths)]
if (length(missing)) stop("Evidence integration requires: ", paste(missing, collapse = ", "))
mr <- data.table::fread(paths[["mr"]])
replication <- data.table::fread(paths[["replication"]])
coloc <- data.table::fread(paths[["coloc"]])
assert_columns(replication, c("lipid", "p", "same_direction"), "replication")
assert_columns(coloc, c("lipid", "pp_h4"), "colocalization")

evidence <- merge(mr, replication[, .(lipid, replication_p = p, same_direction)], by = "lipid", all.x = TRUE)
coloc_best <- coloc[, .(pp_h4 = max(pp_h4, na.rm = TRUE)), by = lipid]
evidence <- merge(evidence, coloc_best, by = "lipid", all.x = TRUE)
evidence[, tier := data.table::fcase(
  fdr_bh < cfg$tiering$tier1$primary_fdr_lt &
    replication_p < cfg$tiering$tier1$replication_p_lt &
    same_direction %in% TRUE & pp_h4 >= cfg$tiering$tier1$coloc_pp_h4_ge,
  "Tier 1",
  fdr_bh < cfg$tiering$tier1$primary_fdr_lt & same_direction %in% TRUE,
  "Tier 2",
  default = "Exploratory"
)]
write_audit_tsv(evidence, "integrated_evidence.tsv")


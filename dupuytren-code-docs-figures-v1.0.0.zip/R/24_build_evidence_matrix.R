#!/usr/bin/env Rscript
source("R/utils.R")

robust <- data.table::fread("results/tables/scrna_mesenchyme_robustness_summary.tsv")
bulk <- data.table::fread("results/tables/scrna_bulk_integration_summary.tsv")
tri <- data.table::fread("results/tables/cross_cohort_integration_summary.tsv")
locus <- data.table::fread("results/tables/exploratory_gene_locus_audit.tsv")
external <- data.table::fread("results/tables/Zenodo14017529_external_direction_summary.tsv")
external_n <- external[metric == "primary_two_source_FDR_genes_available_in_external_selected_set", value][1]
external_fraction <- external[metric == "three_source_direction_concordance_fraction", value][1]
matrix <- data.frame(
  evidence_domain = c(
    "Lipidome-wide genetic causality", "MD specificity", "Pathological PDPN/FAP-like state",
    "Broad mesenchymal disease signature", "Independent bulk direction check",
    "Lipid-metabolism target triangulation", "Exploratory three-dataset genes", "GWAS context for exploratory genes"
  ),
  result = c(
    "Two prespecified lipid-MR scans had no BH-FDR-positive lipid",
    "MD score correlated with ECM and TGF-beta scores above the frozen threshold",
    "Author-reported state is descriptively concentrated in Dupuytren donors and stable to QC definition",
    "257 genes at BH FDR < 0.05; leave-one-donor-out direction stable",
    paste0(bulk[metric == "concordance_fraction_among_both_FDR", value][1] * 100,
      "% direction concordance among jointly significant genes; ", external_n,
      " preselected genes had ", external_fraction * 100, "% three-source direction agreement in the restricted Zenodo set"),
    "No lipid-pathway gene passed single-cell and bulk FDR with concordant direction",
    paste0(tri[metric == "triangulated_directional_support", value][1], " genes meet the directional rule"),
    paste0(sum(locus$genome_wide_significant, na.rm = TRUE), " of ", sum(!is.na(locus$genome_wide_significant)), " assessable loci genome-wide significant")
  ),
  evidence_grade = c("Negative, confirmatory", "Negative for specificity", "Descriptive localization", "Discovery with robustness audit",
    "Independent directional validation", "Negative for target advancement", "Exploratory", "Negative genetic context"),
  permitted_claim = c(
    "No large, reproducibly supported circulating complex-lipid effect was detected",
    "Do not use MD in the title or headline conclusion",
    "Location of a previously reported pathological state; no compositional p-value",
    "A robust mixed-mesenchymal tissue signature exists in this dataset",
    "Cross-platform tissue-level direction is consistent; the Zenodo component is restricted-set support, not an unbiased replication rate",
    "No lipid enzyme/receptor should be claimed as a target",
    "Genes are hypotheses for future validation only",
    "Do not call any exploratory gene a Dupuytren genetic-risk gene; one X-chromosome locus is not covered by this source GWAS"
  ),
  stringsAsFactors = FALSE
)
write_audit_tsv(matrix, "final_evidence_matrix.tsv")
message("Wrote final evidence matrix")

#!/usr/bin/env Rscript
source("R/utils.R")
cfg <- read_analysis_config()

metadata_path <- "results/tables/GSE173252_standardized_cell_metadata.tsv"
if (!file.exists(metadata_path)) stop("Run R/11_standardize_GSE173252_metadata.R first")
obj <- gse173252_author_object()
counts <- gse173252_raw_counts(obj)
meta <- data.table::fread(metadata_path)
assert_columns(meta, c("cell_barcode", "donor_id", "condition", "tissue", "cell_type", "author_cluster", "analysis_keep"),
  "standardized GSE173252 metadata")
meta <- meta[analysis_keep == TRUE]
data.table::setkey(meta, cell_barcode)
keep_cells <- intersect(colnames(counts), meta$cell_barcode)
counts <- counts[, keep_cells, drop = FALSE]
meta <- meta[keep_cells]
if (!identical(meta$cell_barcode, colnames(counts))) stop("Metadata ordering failed")

# Annotation is deliberately conservative. Cluster 3 is the source paper's
# DD-enriched PDPN/FAP/POSTN/SCX state; its label means 'like', not proof of a
# lineage or a novel discovery. Other states retain marker-based descriptors.
meta[, mesenchyme_state := "not_mesenchyme"]
meta[cell_type == "Mesenchyme" & author_cluster == "3", mesenchyme_state := "Pathogenic_PDPN_FAP_like"]
meta[cell_type == "Mesenchyme" & author_cluster == "0", mesenchyme_state := "Resident_fibroblast_CXCL14_SFRP2_like"]
meta[cell_type == "Mesenchyme" & author_cluster == "7", mesenchyme_state := "Resident_fibroblast_COL14A1_like"]
meta[cell_type == "Mesenchyme" & author_cluster == "2", mesenchyme_state := "Pericyte_RGS5_MCAM_like"]
meta[cell_type == "Mesenchyme" & author_cluster == "14", mesenchyme_state := "Resident_fibroblast_CXCL14_hi_like"]
meta[cell_type == "Mesenchyme" & mesenchyme_state == "not_mesenchyme", mesenchyme_state := "Other_mesenchyme"]
write_audit_tsv(meta, "scrna_analysis_cell_metadata.tsv")

read_gmt <- function(path) {
  lines <- strsplit(readLines(path, warn = FALSE), "\t", fixed = TRUE)
  stats::setNames(lapply(lines, function(x) unique(x[-c(1, 2)])), vapply(lines, `[[`, character(1), 1))
}
gene_sets <- read_gmt("config/gene_sets.gmt")
control_sets <- c("ECM_COLLAGEN_CORE", "TGF_BETA_RESPONSE_CORE", "MYOFIBROBLAST_CORE", "CELL_CYCLE_CORE")
gene_sets[["LU2025_MD_NONOVERLAP"]] <- setdiff(gene_sets[["LU2025_MD_SCORE"]], unique(unlist(gene_sets[control_sets])))
if (length(gene_sets[["LU2025_MD_SCORE"]]) != 205 || length(gene_sets[["LU2025_MD_NONOVERLAP"]]) < 50) {
  stop("Unexpected MD gene-set content")
}

scores <- UCell::ScoreSignatures_UCell(matrix = counts, features = gene_sets, maxRank = 1500, chunk.size = 200)
scores <- as.data.frame(scores)
scores$cell_barcode <- rownames(scores)
score_cols <- setdiff(colnames(scores), "cell_barcode")
score_meta <- merge(meta, scores, by = "cell_barcode", sort = FALSE)
if (nrow(score_meta) != nrow(meta)) stop("Program-score merge failed")
write_audit_tsv(score_meta[, c("cell_barcode", score_cols), with = FALSE], "scrna_cell_program_scores.tsv")

donor_scores <- score_meta[, lapply(.SD, median, na.rm = TRUE),
  by = .(donor_id, condition, tissue, cell_type, mesenchyme_state), .SDcols = score_cols]
n_cells_by_group <- score_meta[, .(n_cells = .N),
  by = .(donor_id, condition, tissue, cell_type, mesenchyme_state)]
donor_scores <- merge(donor_scores, n_cells_by_group,
  by = c("donor_id", "condition", "tissue", "cell_type", "mesenchyme_state"), sort = FALSE)
write_audit_tsv(donor_scores, "scrna_donor_program_scores.tsv")

md_cols <- c("LU2025_MD_SCORE_UCell", "LU2025_MD_NONOVERLAP_UCell")
controls <- paste0(c("ECM_COLLAGEN_CORE", "TGF_BETA_RESPONSE_CORE", "MYOFIBROBLAST_CORE", "CELL_CYCLE_CORE"), "_UCell")
mes_scores <- donor_scores[cell_type == "Mesenchyme" & n_cells >= cfg$single_cell$pseudobulk_min_cells]
cor_rows <- list()
for (md_col in md_cols) {
  for (control in controls) {
    cor_rows[[paste(md_col, control)]] <- data.frame(
      md_program = md_col, control_program = control, scope = "all_mesenchymal_donor_states",
      n = nrow(mes_scores), rho = cor(mes_scores[[md_col]], mes_scores[[control]], method = "spearman", use = "pairwise.complete.obs")
    )
  }
}
cor_tab <- data.table::rbindlist(cor_rows)
cor_tab[, md_collinear := abs(rho) >= cfg$single_cell$md_remove_if_correlation_ge]
write_audit_tsv(cor_tab, "scrna_md_specificity_correlations.tsv")

# Donor-level state composition is descriptive because there are only three
# donors per condition and cell recovery is not a random tissue sample.
mes <- meta[cell_type == "Mesenchyme"]
composition <- mes[, .N, by = .(donor_id, condition, tissue, mesenchyme_state)]
composition[, mesenchymal_cells_per_donor := sum(N), by = donor_id]
composition[, fraction_of_mesenchyme := N / mesenchymal_cells_per_donor]
write_audit_tsv(composition, "scrna_mesenchyme_state_composition.tsv")

make_pseudobulk <- function(meta_in, group_variable, level) {
  group <- interaction(meta_in$donor_id, meta_in[[group_variable]], drop = TRUE, sep = "||")
  design_matrix <- Matrix::sparse.model.matrix(~ 0 + group)
  pb <- counts[, meta_in$cell_barcode, drop = FALSE] %*% design_matrix
  colnames(pb) <- sub("^group", "", colnames(pb))
  sample_info <- unique(data.frame(
    pseudobulk_id = as.character(group), donor_id = meta_in$donor_id,
    condition = meta_in$condition, tissue = meta_in$tissue,
    analysis_state = meta_in[[group_variable]], analysis_level = level,
    stringsAsFactors = FALSE
  ))
  sample_info$n_cells <- as.integer(table(group)[sample_info$pseudobulk_id])
  sample_info <- sample_info[sample_info$n_cells >= cfg$single_cell$pseudobulk_min_cells, ]
  list(counts = pb, sample_info = sample_info)
}

run_de <- function(pb, sample_info) {
  results <- list()
  for (state in unique(sample_info$analysis_state)) {
    sample_meta <- sample_info[sample_info$analysis_state == state & sample_info$condition %in% c("Dupuytren", "Skoog"), ]
    if (length(unique(sample_meta$donor_id[sample_meta$condition == "Dupuytren"])) < cfg$single_cell$minimum_donors_per_condition ||
        length(unique(sample_meta$donor_id[sample_meta$condition == "Skoog"])) < cfg$single_cell$minimum_donors_per_condition) next
    y <- edgeR::DGEList(pb[, sample_meta$pseudobulk_id, drop = FALSE])
    keep <- edgeR::filterByExpr(y, group = sample_meta$condition)
    if (sum(keep) < 20) next
    y <- edgeR::calcNormFactors(y[keep, , keep.lib.sizes = FALSE])
    design <- model.matrix(~ 0 + condition, sample_meta)
    y <- edgeR::estimateDisp(y, design, robust = TRUE)
    fit <- edgeR::glmQLFit(y, design, robust = TRUE)
    contrast <- limma::makeContrasts(conditionDupuytren - conditionSkoog, levels = design)
    tab <- edgeR::topTags(edgeR::glmQLFTest(fit, contrast = contrast), n = Inf)$table
    tab$gene <- rownames(tab)
    tab$analysis_state <- state
    tab$analysis_level <- unique(sample_meta$analysis_level)
    tab$n_dupuytren_donors <- length(unique(sample_meta$donor_id[sample_meta$condition == "Dupuytren"]))
    tab$n_skoog_donors <- length(unique(sample_meta$donor_id[sample_meta$condition == "Skoog"]))
    results[[paste(unique(sample_meta$analysis_level), state)]] <- tab
  }
  data.table::rbindlist(results, fill = TRUE)
}

broad <- make_pseudobulk(meta, "cell_type", "broad_cell_type")
mes_state <- make_pseudobulk(meta[cell_type == "Mesenchyme"], "mesenchyme_state", "mesenchyme_state")
sample_info <- data.table::rbindlist(list(broad$sample_info, mes_state$sample_info), fill = TRUE)
write_audit_tsv(sample_info, "scrna_pseudobulk_samples.tsv")
de <- data.table::rbindlist(list(run_de(broad$counts, broad$sample_info), run_de(mes_state$counts, mes_state$sample_info)), fill = TRUE)
if (!nrow(de)) stop("No donor-level pseudobulk contrast was estimable")
de[, FDR_within_state := p.adjust(PValue, method = "BH"), by = .(analysis_level, analysis_state)]
write_audit_tsv(de, "scrna_pseudobulk_de.tsv")

decision <- data.frame(
  criterion = c("MD-vs-control program correlation", "non-overlapping MD signature", "cell-cycle confounding"),
  status = c(
    ifelse(any(cor_tab[md_program == "LU2025_MD_SCORE_UCell", md_collinear]), "fails_remove_MD_from_title", "passes_screen"),
    ifelse(any(cor_tab[md_program == "LU2025_MD_NONOVERLAP_UCell", md_collinear]), "fails_remove_MD_from_title", "pending DE_direction_stability_review"),
    "not_interpretable_as_primary_MD_evidence"
  ),
  note = c("MD title is removed if any prespecified ECM/TGF-beta/myofibroblast correlation reaches absolute rho 0.80",
    "Requires stable disease direction for the non-overlapping gene subset", "Reported as a separate program, never silently adjusted away")
)
write_audit_tsv(decision, "scrna_md_narrative_decision.tsv")
message("Completed donor-level program scoring and pseudobulk analysis for ", ncol(counts), " QC-passing cells")

#!/usr/bin/env Rscript
source("R/utils.R")

stage1_path <- "results/tables/mr_primary.tsv"
stage2_path <- "results/tables/stage2_mr_primary.tsv"
if (!file.exists(stage1_path) || !file.exists(stage2_path)) {
  stop("Both Stage 1 and Stage 2 primary MR tables are required")
}

read_screen <- function(path, label) {
  d <- data.table::fread(path)
  assert_columns(d, c("lipid", "beta", "p", "fdr_bh", "n_snp"), label)
  d[, stage := label]
  d[, neglog10p := -log10(pmax(p, .Machine$double.xmin))]
  d[, fdr_pass := fdr_bh < 0.05]
  d
}

d <- data.table::rbindlist(list(
  read_screen(stage1_path, "Stage 1: Cadby 2022"),
  read_screen(stage2_path, "Stage 2: Landstra 2026 Model 1")
))

# Save a transparent data table that directly underlies the plot.
top <- d[, .SD[order(p)][seq_len(min(.N, 20L))], by = stage]
data.table::fwrite(top, "results/tables/top_nominal_lipid_signals.tsv", sep = "\t", na = "NA")

if (!requireNamespace("ggplot2", quietly = TRUE)) stop("Install ggplot2")
library(ggplot2)
figure_dir <- file.path(project_root(), "results", "figures")
ensure_dir(figure_dir)

p <- ggplot(d, aes(x = beta, y = neglog10p)) +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "grey50", linewidth = 0.35) +
  geom_point(aes(size = n_snp), color = "#3D6E9E", alpha = 0.70) +
  geom_text(
    data = top, aes(label = lipid), size = 2.25, vjust = -0.55,
    check_overlap = TRUE, color = "#1F1F1F"
  ) +
  facet_wrap(~stage, scales = "free_y") +
  scale_size_continuous(name = "Harmonized SNPs", range = c(1.2, 4.0)) +
  labs(
    x = "MR log odds ratio for Dupuytren disease per 1-SD higher lipid",
    y = expression(-log[10](italic(P))),
    title = "Two independently specified lipid MR screens were FDR-negative",
    subtitle = "Labels denote the 20 smallest nominal P values per screen; dashed line is nominal P=0.05"
  ) +
  theme_classic(base_size = 10) +
  theme(
    strip.background = element_rect(fill = "#EDF3F8", color = NA),
    strip.text = element_text(face = "bold"),
    plot.title = element_text(face = "bold"),
    legend.position = "bottom"
  )

ggsave(file.path(figure_dir, "mr_screen_landscape.png"), p, width = 11, height = 5.7, dpi = 300)
ggsave(file.path(figure_dir, "mr_screen_landscape.pdf"), p, width = 11, height = 5.7)
message("Wrote negative-screen landscape figures and top nominal-signal table")

#!/usr/bin/env Rscript
source("R/utils.R")

# This audit is intentionally limited to the broad mesenchymal comparison.
# The PDPN/FAP-like state has no adequate Skoog representation, so an apparent
# state-specific sensitivity p-value would not be valid.
meta_all <- data.table::fread("results/tables/GSE173252_standardized_cell_metadata.tsv")
obj <- gse173252_author_object()
counts_all <- gse173252_raw_counts(obj)

annotate_state <- function(meta) {
  meta <- data.table::copy(meta)
  meta[, mesenchyme_state := "not_mesenchyme"]
  meta[cell_type == "Mesenchyme" & author_cluster == "3", mesenchyme_state := "Pathogenic_PDPN_FAP_like"]
  meta[cell_type == "Mesenchyme" & author_cluster == "0", mesenchyme_state := "Resident_fibroblast_CXCL14_SFRP2_like"]
  meta[cell_type == "Mesenchyme" & author_cluster == "7", mesenchyme_state := "Resident_fibroblast_COL14A1_like"]
  meta[cell_type == "Mesenchyme" & author_cluster == "2", mesenchyme_state := "Pericyte_RGS5_MCAM_like"]
  meta[cell_type == "Mesenchyme" & author_cluster == "14", mesenchyme_state := "Resident_fibroblast_CXCL14_hi_like"]
  meta[cell_type == "Mesenchyme" & mesenchyme_state == "not_mesenchyme", mesenchyme_state := "Other_mesenchyme"]
  meta
}

run_mesenchymal_de <- function(meta, label) {
  meta <- annotate_state(meta[cell_type == "Mesenchyme" & condition %in% c("Dupuytren", "Skoog")])
  # Reorder both objects together; explicit matching prevents an accidental
  # cell-count/metadata mismatch when the QC definition changes.
  cells <- intersect(colnames(counts_all), meta$cell_barcode)
  meta <- meta[match(cells, cell_barcode)]
  if (!identical(meta$cell_barcode, cells)) stop("Cell ordering failed for ", label)
  count_sub <- counts_all[, cells, drop = FALSE]
  donor <- factor(meta$donor_id)
  aggregation <- Matrix::sparse.model.matrix(~ 0 + donor)
  pb <- count_sub %*% aggregation
  colnames(pb) <- sub("^donor", "", colnames(pb))
  sample_meta <- unique(data.frame(donor_id = meta$donor_id, condition = meta$condition, stringsAsFactors = FALSE))
  sample_meta <- sample_meta[match(colnames(pb), sample_meta$donor_id), ]
  if (anyNA(sample_meta$condition) || length(unique(sample_meta$donor_id[sample_meta$condition == "Dupuytren"])) < 2L ||
      length(unique(sample_meta$donor_id[sample_meta$condition == "Skoog"])) < 2L) stop("Insufficient donors for ", label)
  y <- edgeR::DGEList(pb)
  keep <- edgeR::filterByExpr(y, group = sample_meta$condition)
  y <- edgeR::calcNormFactors(y[keep, , keep.lib.sizes = FALSE])
  design <- model.matrix(~ 0 + condition, sample_meta)
  y <- edgeR::estimateDisp(y, design, robust = TRUE)
  fit <- edgeR::glmQLFit(y, design, robust = TRUE)
  contrast <- limma::makeContrasts(conditionDupuytren - conditionSkoog, levels = design)
  out <- edgeR::topTags(edgeR::glmQLFTest(fit, contrast = contrast), n = Inf)$table
  out$gene <- rownames(out)
  out$FDR <- p.adjust(out$PValue, method = "BH")
  out$analysis <- label
  out
}

strict_meta <- meta_all[analysis_keep == TRUE]
relaxed_meta <- meta_all[author_doublet == FALSE]
baseline <- run_mesenchymal_de(strict_meta, "strict_baseline")
relaxed <- run_mesenchymal_de(relaxed_meta, "author_doublet_only_QC")

donors <- sort(unique(strict_meta[condition %in% c("Dupuytren", "Skoog"), donor_id]))
lodo <- lapply(donors, function(held_out) run_mesenchymal_de(strict_meta[donor_id != held_out], paste0("leave_out_", held_out)))
lodo <- data.table::rbindlist(lodo, fill = TRUE)
write_audit_tsv(lodo, "scrna_mesenchyme_lodo_de.tsv")

compare_with_baseline <- function(candidate, name) {
  base_dt <- data.table::as.data.table(baseline)
  candidate_dt <- data.table::as.data.table(candidate)
  x <- merge(base_dt[, .(gene, baseline_logFC = logFC, baseline_FDR = FDR)],
    candidate_dt[, .(gene, sensitivity_logFC = logFC, sensitivity_FDR = FDR)], by = "gene")
  x[, analysis := name]
  x[, direction_concordant := sign(baseline_logFC) == sign(sensitivity_logFC)]
  x
}
qc_compare <- compare_with_baseline(relaxed, "author_doublet_only_QC")
write_audit_tsv(qc_compare, "scrna_mesenchyme_qc_sensitivity.tsv")
lodo_compare <- data.table::rbindlist(lapply(split(lodo, lodo$analysis), function(x) compare_with_baseline(x, unique(x$analysis))), fill = TRUE)
write_audit_tsv(lodo_compare, "scrna_mesenchyme_lodo_sensitivity.tsv")

summarise_comparison <- function(x, label) {
  target <- x[baseline_FDR < 0.05]
  data.frame(analysis = label, n_shared_genes = nrow(x), n_baseline_FDR_lt_005 = nrow(target),
    concordant_baseline_FDR_genes = sum(target$direction_concordant),
    concordance_fraction = mean(target$direction_concordant),
    all_gene_spearman_rho = cor(x$baseline_logFC, x$sensitivity_logFC, method = "spearman"))
}
summary <- data.table::rbindlist(c(
  list(summarise_comparison(qc_compare, "author_doublet_only_QC")),
  lapply(split(lodo_compare, lodo_compare$analysis), function(x) summarise_comparison(x, unique(x$analysis)))
), fill = TRUE)
write_audit_tsv(summary, "scrna_mesenchyme_robustness_summary.tsv")

state_composition <- function(meta, label) {
  mes <- annotate_state(meta[cell_type == "Mesenchyme"])
  out <- mes[, .N, by = .(donor_id, condition, mesenchyme_state)]
  out[, total_mesenchymal_cells := sum(N), by = donor_id]
  out[, fraction_of_mesenchyme := N / total_mesenchymal_cells]
  out[, qc_definition := label]
  out
}
write_audit_tsv(data.table::rbindlist(list(
  state_composition(strict_meta, "strict_MAD_QC"),
  state_composition(relaxed_meta, "author_doublet_only_QC")
)), "scrna_state_composition_qc_sensitivity.tsv")
message("Completed mesenchymal leave-one-donor-out and QC sensitivity audit")

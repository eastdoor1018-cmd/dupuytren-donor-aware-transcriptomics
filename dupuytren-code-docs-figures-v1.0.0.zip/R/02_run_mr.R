#!/usr/bin/env Rscript
source("R/utils.R")
cfg <- read_analysis_config()

exposure_path <- Sys.getenv("MR_EXPOSURE_PATH", unset = "data/derived/mr_exposure_instruments.tsv")
outcome_path <- Sys.getenv("MR_OUTCOME_PATH", unset = "data/derived/GCST90301252_instrument_associations.tsv")
output_prefix <- Sys.getenv("MR_OUTPUT_PREFIX", unset = "")
if (!file.exists(exposure_path)) stop("Missing ", exposure_path, "; run R/01_prepare_mr_inputs.R")
if (!file.exists(outcome_path)) stop("Missing ", outcome_path, "; run the primary-mr download/extraction stage")

exp <- data.table::fread(exposure_path)
out <- data.table::fread(outcome_path)
assert_columns(exp, c("SNP", "lipid", "beta", "se", "effect_allele", "other_allele"), "exposure")
assert_columns(out, c("SNP", "beta", "se", "effect_allele", "other_allele"), "outcome")

results <- list()
harmonized <- list()
coverage <- list()
sensitivity <- list()
leave_one_out <- list()
for (trait in unique(exp$lipid)) {
  e <- as.data.frame(exp[lipid == trait])
  # Some published significant-signal tables report only the effect allele.
  # Infer the non-effect allele conservatively from the biallelic outcome only
  # when the reported effect allele is one of the two outcome alleles.
  if ("other_allele" %in% names(e) && any(is.na(e$other_allele) | !nzchar(e$other_allele))) {
    idx <- match(e$SNP, out$SNP)
    ea <- toupper(e$effect_allele)
    out_ea <- toupper(out$effect_allele[idx])
    out_oa <- toupper(out$other_allele[idx])
    inferred <- ifelse(ea == out_ea, out_oa, ifelse(ea == out_oa, out_ea, NA_character_))
    missing_oa <- is.na(e$other_allele) | !nzchar(e$other_allele)
    e$other_allele[missing_oa] <- inferred[missing_oa]
  }
  h <- harmonize_pair(e, as.data.frame(out), cfg$mr$palindromic_maf_max)
  if (nrow(h)) {
    h$lipid <- rep(trait, nrow(h))
    harmonized[[trait]] <- h
  }
  m <- h[h$mr_keep, , drop = FALSE]
  coverage[[trait]] <- data.frame(
    lipid = trait, n_instruments = nrow(e), n_outcome_matched = nrow(h),
    n_harmonized = nrow(m),
    status = if (!nrow(h)) "no_outcome_match" else if (!nrow(m)) "all_removed_harmonization" else "estimable"
  )
  if (!nrow(m)) next
  fit <- if (nrow(m) == 1) {
    wald_ratio(m$beta.exposure, m$beta.outcome, m$se.exposure, m$se.outcome)
  } else {
    ivw_random(m$beta.exposure, m$beta.outcome, m$se.outcome)
  }
  results[[trait]] <- data.frame(
    lipid = trait, method = if (nrow(m) == 1) "Wald ratio" else "random-effects IVW",
    beta = fit$beta, se = fit$se, p = fit$p, n_snp = fit$n_snp,
    q = if (!is.null(fit$q)) fit$q else NA_real_,
    q_df = if (!is.null(fit$q_df)) fit$q_df else NA_integer_,
    q_p = if (!is.null(fit$q_p)) fit$q_p else NA_real_
  )

  if (nrow(m) >= cfg$mr$weighted_median_min_snps) {
    wm <- tryCatch(
      TwoSampleMR::mr_weighted_median(m$beta.exposure, m$beta.outcome, m$se.exposure, m$se.outcome),
      error = function(e) NULL
    )
    if (!is.null(wm)) sensitivity[[paste(trait, "wm")]] <- data.frame(
      lipid = trait, method = "weighted median", beta = wm$b, se = wm$se,
      p = wm$pval, n_snp = wm$nsnp, intercept = NA_real_, intercept_p = NA_real_,
      global_pleiotropy_p = NA_real_
    )
  }
  if (nrow(m) >= cfg$mr$raps_min_snps) {
    raps <- tryCatch(
      suppressWarnings(mr.raps::mr.raps.overdispersed.robust(
        m$beta.exposure, m$beta.outcome, m$se.exposure, m$se.outcome
      )), error = function(e) NULL
    )
    if (!is.null(raps)) sensitivity[[paste(trait, "raps")]] <- data.frame(
      lipid = trait, method = "MR-RAPS", beta = raps$beta.hat, se = raps$beta.se,
      p = raps$beta.p.value, n_snp = nrow(m), intercept = NA_real_,
      intercept_p = NA_real_, global_pleiotropy_p = NA_real_
    )
  }
  if (nrow(m) >= cfg$mr$egger_min_snps) {
    egger <- tryCatch(
      TwoSampleMR::mr_egger_regression(m$beta.exposure, m$beta.outcome, m$se.exposure, m$se.outcome),
      error = function(e) NULL
    )
    if (!is.null(egger)) sensitivity[[paste(trait, "egger")]] <- data.frame(
      lipid = trait, method = "MR-Egger", beta = egger$b, se = egger$se,
      p = egger$pval, n_snp = egger$nsnp, intercept = egger$b_i,
      intercept_p = egger$pval_i, global_pleiotropy_p = NA_real_
    )
  }
  if (nrow(m) >= 4) {
    presso_data <- data.frame(
      bx = m$beta.exposure, by = m$beta.outcome,
      sx = m$se.exposure, sy = m$se.outcome
    )
    presso <- tryCatch(
      suppressWarnings(MRPRESSO::mr_presso(
        BetaOutcome = "by", BetaExposure = "bx", SdOutcome = "sy", SdExposure = "sx",
        data = presso_data, OUTLIERtest = TRUE, DISTORTIONtest = TRUE,
        NbDistribution = 1000, seed = cfg$project$random_seed
      )), error = function(e) NULL
    )
    if (!is.null(presso)) {
      raw <- presso[["Main MR results"]][1, ]
      global_p <- presso[["MR-PRESSO results"]][["Global Test"]][["Pvalue"]]
      sensitivity[[paste(trait, "presso")]] <- data.frame(
        lipid = trait, method = "MR-PRESSO raw", beta = raw[["Causal Estimate"]],
        se = raw[["Sd"]], p = raw[["P-value"]], n_snp = nrow(m),
        intercept = NA_real_, intercept_p = NA_real_, global_pleiotropy_p = global_p
      )
    }
  }
  if (nrow(m) >= 2) {
    for (j in seq_len(nrow(m))) {
      loo <- m[-j, , drop = FALSE]
      loo_fit <- if (nrow(loo) == 1) {
        wald_ratio(loo$beta.exposure, loo$beta.outcome, loo$se.exposure, loo$se.outcome)
      } else {
        ivw_random(loo$beta.exposure, loo$beta.outcome, loo$se.outcome)
      }
      leave_one_out[[paste(trait, j)]] <- data.frame(
        lipid = trait, omitted_snp = m$SNP[[j]], beta = loo_fit$beta,
        se = loo_fit$se, p = loo_fit$p, n_snp = loo_fit$n_snp
      )
    }
  }
}

harm <- data.table::rbindlist(harmonized, fill = TRUE)
coverage <- data.table::rbindlist(coverage, fill = TRUE)
res <- data.table::rbindlist(results, fill = TRUE)
if (!nrow(res)) stop("No harmonized lipid-outcome associations were estimable")
res[, fdr_bh := p.adjust(p, method = "BH")]
res[, p_bonferroni := p.adjust(p, method = "bonferroni")]
res[, primary_pass := fdr_bh < cfg$mr$fdr_threshold]
data.table::setorder(res, p)

write_audit_tsv(harm, paste0(output_prefix, "mr_harmonization_audit.tsv"))
write_audit_tsv(coverage, paste0(output_prefix, "mr_instrument_coverage.tsv"))
write_audit_tsv(res, paste0(output_prefix, "mr_primary.tsv"))
write_audit_tsv(res[primary_pass == TRUE], paste0(output_prefix, "mr_candidates.tsv"))
write_audit_tsv(data.table::rbindlist(sensitivity, fill = TRUE), paste0(output_prefix, "mr_sensitivity.tsv"))
write_audit_tsv(data.table::rbindlist(leave_one_out, fill = TRUE), paste0(output_prefix, "mr_leave_one_out.tsv"))

# Prespecified null path: use author-defined measured class totals and a Simes
# class enrichment summary. These do not retroactively alter the species-level
# multiplicity family and are clearly labeled secondary.
lipid_dictionary <- unique(exp[, .(lipid, lipid_class)])
annotated <- merge(res, lipid_dictionary, by = "lipid", all.x = TRUE)
class_phenotypes <- annotated[lipid_class == "Totals" | grepl("^Total ", lipid)]
if (nrow(class_phenotypes)) {
  class_phenotypes[, class_fdr_bh := p.adjust(p, method = "BH")]
  write_audit_tsv(class_phenotypes, paste0(output_prefix, "mr_class_phenotypes.tsv"))
}
simes <- function(p) {
  p <- sort(p[is.finite(p)])
  if (!length(p)) return(NA_real_)
  min(1, min(length(p) * p / seq_along(p)))
}
class_enrichment <- annotated[!is.na(lipid_class) & lipid_class != "Totals",
  .(n_lipids = .N, simes_p = simes(p), n_nominal = sum(p < 0.05)), by = lipid_class]
class_enrichment[, fdr_bh := p.adjust(simes_p, method = "BH")]
data.table::setorder(class_enrichment, simes_p)
write_audit_tsv(class_enrichment, paste0(output_prefix, "mr_class_simes_enrichment.tsv"))

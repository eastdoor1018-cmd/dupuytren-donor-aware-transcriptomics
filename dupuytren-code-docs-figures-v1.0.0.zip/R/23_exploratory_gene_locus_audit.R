#!/usr/bin/env Rscript
source("R/utils.R")

# This is a negative genetic-context audit, not a gene-based association test.
loci <- data.table::fread("config/exploratory_gene_loci_grch37.tsv")
gwas <- data.table::fread("data/raw/gwas_catalog/GCST90301252/GCST90301252.tsv")
required <- c("chromosome", "base_pair_location", "p_value", "rs_id")
assert_columns(gwas, required, "GCST90301252 sumstats")
window_bp <- 500000L
out <- lapply(seq_len(nrow(loci)), function(i) {
  loc <- loci[i]
  chr <- suppressWarnings(as.integer(loc$chromosome))
  if (is.na(chr)) return(data.frame(gene = loc$gene, chromosome = loc$chromosome,
    start_grch37 = loc$start_grch37, end_grch37 = loc$end_grch37, window_bp = window_bp,
    n_variants = NA_integer_, lead_rs_id = NA_character_, lead_position_grch37 = NA_integer_,
    lead_p_value = NA_real_, genome_wide_significant = NA, coverage = "chromosome_not_present_in_source_GWAS",
    stringsAsFactors = FALSE))
  region <- gwas[chromosome == chr & base_pair_location >= loc$start_grch37 - window_bp &
    base_pair_location <= loc$end_grch37 + window_bp]
  region <- region[order(p_value)]
  if (!nrow(region)) return(data.frame(gene = loc$gene, chromosome = loc$chromosome,
    start_grch37 = loc$start_grch37, end_grch37 = loc$end_grch37, window_bp = window_bp,
    n_variants = 0L, lead_rs_id = NA_character_, lead_position_grch37 = NA_integer_, lead_p_value = NA_real_,
    genome_wide_significant = NA, coverage = "no_variants_in_window", stringsAsFactors = FALSE))
  data.frame(gene = loc$gene, chromosome = loc$chromosome, start_grch37 = loc$start_grch37,
    end_grch37 = loc$end_grch37, window_bp = window_bp, n_variants = nrow(region),
    lead_rs_id = region$rs_id[1], lead_position_grch37 = region$base_pair_location[1],
    lead_p_value = region$p_value[1], genome_wide_significant = region$p_value[1] < 5e-8,
    coverage = "assessable",
    stringsAsFactors = FALSE)
})
write_audit_tsv(data.table::rbindlist(out, fill = TRUE), "exploratory_gene_locus_audit.tsv")
message("Completed exploratory-gene GWAS locus audit")

#!/usr/bin/env Rscript
source("R/utils.R")

# Galan Novella et al. (2025) deposit sample-level values for an AUTHOR-SELECTED
# 237-gene differential-expression table, not a full count matrix. The file is
# therefore eligible only for an external direction check of signatures fixed
# before opening it; it cannot be used for a fresh transcriptome-wide scan.
input <- "data/raw/zenodo/14017529/EXPRESSION VALUES.xlsx"
expected_md5 <- "867f682ea840d99fad08c345536c9702"
if (!file.exists(input)) stop("Missing Zenodo workbook: ", input)
if (!requireNamespace("openxlsx", quietly = TRUE)) stop("Install package 'openxlsx'")
if (tolower(tools::md5sum(input)[[1]]) != expected_md5) stop("Zenodo MD5 checksum mismatch")

raw <- openxlsx::read.xlsx(input, sheet = 1, colNames = FALSE,
  skipEmptyRows = FALSE, skipEmptyCols = FALSE)
if (nrow(raw) < 4L || ncol(raw) < 15L) stop("Unexpected Zenodo workbook dimensions")
header <- as.character(unlist(raw[2, ]))
sample_labels <- as.character(unlist(raw[1, 14:ncol(raw)]))
if (!identical(header[1:13], c("gene_id", "seqnames", "start", "end", "type", "gene_type", "gene_name",
  "baseMean", "log2FoldChange", "lfcSE", "stat", "pvalue", "padj"))) stop("Unexpected annotation columns")
condition <- ifelse(grepl("^DD[0-9]+$", sample_labels), "Dupuytren",
  ifelse(grepl("^CTR[0-9]+$", sample_labels), "Control", NA_character_))
if (anyNA(condition) || sum(condition == "Dupuytren") != 26L || sum(condition == "Control") != 17L) {
  stop("Expected 26 Dupuytren and 17 control labels")
}

ann <- data.frame(
  gene_id = sub("\\..*$", "", as.character(unlist(raw[3:nrow(raw), 1]))),
  gene = as.character(unlist(raw[3:nrow(raw), 7])),
  reported_baseMean = as.numeric(unlist(raw[3:nrow(raw), 8])),
  reported_log2FC = as.numeric(unlist(raw[3:nrow(raw), 9])),
  reported_pvalue = as.numeric(unlist(raw[3:nrow(raw), 12])),
  reported_padj = as.numeric(unlist(raw[3:nrow(raw), 13])),
  stringsAsFactors = FALSE
)
values <- as.matrix(raw[3:nrow(raw), 14:ncol(raw)])
storage.mode(values) <- "numeric"
colnames(values) <- sample_labels
if (any(!is.finite(values)) || any(values < 0)) stop("Expression values must be finite and non-negative")
if (anyNA(ann$gene) || any(!nzchar(ann$gene))) stop("Missing gene symbols in Zenodo workbook")

# One duplicate symbol occurs. Retaining the row with the smallest published
# adjusted P value makes the collapse deterministic while leaving the original
# annotation and values in the raw workbook untouched.
keep <- order(ann$gene, ann$reported_padj, ann$gene_id)
keep <- keep[!duplicated(ann$gene[keep])]
ann <- ann[keep, , drop = FALSE]
values <- values[keep, , drop = FALSE]
rownames(values) <- ann$gene

sample_meta <- data.frame(sample_id = sample_labels, condition = condition,
  author_sample_id = as.character(unlist(raw[2, 14:ncol(raw)])), stringsAsFactors = FALSE)
log_expr <- log2(values + 1)
design <- model.matrix(~ 0 + condition, sample_meta)
contrast <- limma::makeContrasts(conditionDupuytren - conditionControl, levels = design)
fit <- limma::eBayes(limma::contrasts.fit(limma::lmFit(log_expr, design), contrast), trend = TRUE, robust = TRUE)
tab <- limma::topTable(fit, number = Inf, sort.by = "none")
tab$gene <- rownames(fit$coefficients)
tab <- merge(ann, tab, by = "gene", sort = FALSE)
tab$external_set_scope <- "author_selected_237_gene_set"
tab$reported_reanalysis_same_direction <- sign(tab$reported_log2FC) == sign(tab$logFC)

audit <- data.frame(
  metric = c("md5_verified", "workbook_rows_including_headers", "workbook_columns", "author_selected_gene_rows",
    "unique_gene_symbols", "dupuytren_samples", "control_samples", "sample_value_min", "sample_value_median",
    "sample_value_max", "reported_reanalysis_pearson_logFC", "reported_reanalysis_spearman_logFC", "same_direction_fraction"),
  value = c(TRUE, nrow(raw), ncol(raw), nrow(raw) - 2L, nrow(ann), sum(condition == "Dupuytren"), sum(condition == "Control"),
    min(values), median(values), max(values), cor(tab$reported_log2FC, tab$logFC),
    cor(tab$reported_log2FC, tab$logFC, method = "spearman"), mean(tab$reported_reanalysis_same_direction)),
  stringsAsFactors = FALSE
)
write_audit_tsv(data.frame(gene = rownames(values), log_expr, check.names = FALSE), "Zenodo14017529_selected_expression_log2.tsv")
write_audit_tsv(sample_meta, "Zenodo14017529_samples.tsv")
write_audit_tsv(tab, "bulk_Zenodo14017529_selected_set_de.tsv")
write_audit_tsv(audit, "Zenodo14017529_intake_audit.tsv")
message("Prepared Zenodo 14017529 restricted external dataset: ", nrow(ann), " genes across ", nrow(sample_meta), " samples")

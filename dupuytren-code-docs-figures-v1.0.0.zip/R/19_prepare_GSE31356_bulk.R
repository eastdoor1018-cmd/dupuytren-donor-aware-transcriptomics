#!/usr/bin/env Rscript
source("R/utils.R")

# GSE31356 contains three matched Dupuytren and non-diseased tissue pairs on
# Affymetrix HG-U133A. Raw CEL files are RMA-preprocessed. It is a
# direction-only replication cohort, not a source of precise effect sizes.
raw_dir <- "data/raw/geo/GSE31356"
dir.create(raw_dir, recursive = TRUE, showWarnings = FALSE)
gse <- GEOquery::getGEO("GSE31356", GSEMatrix = TRUE, getGPL = FALSE, destdir = raw_dir)[[1]]
if (Biobase::annotation(gse) != "GPL96") stop("Unexpected platform: ", Biobase::annotation(gse))
if (ncol(Biobase::exprs(gse)) != 6L) stop("Unexpected GSE31356 sample count")
cel_dir <- file.path(raw_dir, "cel")
cel_files <- sort(list.files(cel_dir, pattern = "\\.CEL$", full.names = TRUE))
if (length(cel_files) != 6L) stop("Raw CEL files are missing; download GSE31356_RAW.tar before preprocessing")
cel_gsm <- sub("_.*$", "", basename(cel_files))
if (anyDuplicated(cel_gsm)) stop("CEL GSM identifiers are not unique")
raw_cel <- affy::ReadAffy(filenames = cel_files)
rma_cel <- affy::rma(raw_cel)
mat_log <- Biobase::exprs(rma_cel)
colnames(mat_log) <- cel_gsm

platform <- GEOquery::Table(GEOquery::getGEO("GPL96", destdir = raw_dir))
map <- data.frame(probe_id = platform$ID, gene = trimws(platform$`Gene Symbol`), stringsAsFactors = FALSE)
map$gene <- sub(" ///.*$", "", map$gene)
map <- map[!is.na(map$gene) & nzchar(map$gene) & map$probe_id %in% rownames(mat_log), ]
map <- map[!duplicated(map$probe_id), ]
mat <- mat_log[map$probe_id, , drop = FALSE]
rownames(mat) <- map$gene
iqr <- apply(mat, 1, IQR, na.rm = TRUE)
choose <- data.frame(gene = rownames(mat), probe_id = map$probe_id, iqr = iqr, stringsAsFactors = FALSE)
choose <- choose[order(choose$gene, -choose$iqr, choose$probe_id), ]
choose <- choose[!duplicated(choose$gene), ]
mat <- mat[match(choose$gene, rownames(mat)), , drop = FALSE]
rownames(mat) <- choose$gene

pd <- Biobase::pData(gse)
condition <- ifelse(grepl("^ND", pd$title), "Non_diseased", ifelse(grepl("^D", pd$title), "Dupuytren", NA_character_))
patient_id <- ifelse(grepl("^ND", pd$title), sub("^ND", "", pd$title), sub("^D", "", pd$title))
if (anyNA(condition) || !setequal(unique(patient_id), c("2", "6", "18")) ||
    any(table(patient_id) != 2L)) stop("Unable to reconstruct the expected matched pairs")
metadata <- data.frame(sample_id = rownames(pd), condition = condition, patient_id = patient_id,
  title = pd$title, stringsAsFactors = FALSE)
if (!all(metadata$sample_id %in% colnames(mat))) stop("CEL and GEO sample identifiers do not match")
mat <- mat[, metadata$sample_id, drop = FALSE]

write_audit_tsv(data.frame(gene = rownames(mat), mat, check.names = FALSE), "GSE31356_expression.tsv")
write_audit_tsv(metadata, "GSE31356_samples.tsv")
write_audit_tsv(data.frame(metric = c("RMA_probe_sets", "mapped_symbol_probes", "unique_gene_symbols", "samples", "matched_pairs"),
  value = c(nrow(mat_log), nrow(map), nrow(mat), ncol(mat), length(unique(patient_id)))), "GSE31356_preprocessing_audit.tsv")

condition_factor <- factor(metadata$condition, levels = c("Non_diseased", "Dupuytren"))
design <- model.matrix(~ patient_id + condition_factor, metadata)
fit <- limma::lmFit(mat, design)
fit <- limma::eBayes(fit, trend = TRUE, robust = TRUE)
de <- limma::topTable(fit, coef = "condition_factorDupuytren", number = Inf, sort.by = "P")
de$gene <- rownames(de)
write_audit_tsv(de, "bulk_GSE31356_paired_de.tsv")
message("Prepared and analysed GSE31356 paired cohort: ", nrow(mat), " genes")

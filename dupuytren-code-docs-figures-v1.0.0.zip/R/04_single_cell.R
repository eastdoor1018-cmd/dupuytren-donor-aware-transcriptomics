#!/usr/bin/env Rscript
source("R/utils.R")
cfg <- read_analysis_config()

input <- Sys.getenv("GSE173252_STANDARDIZED_RDS", unset = "data/derived/GSE173252_standardized.rds")
if (!file.exists(input)) {
  stop(
    "Missing standardized Seurat object: ", input, "\n",
    "It must contain raw RNA counts and metadata donor_id, condition, tissue, cell_type. ",
    "No cell-level inference will be run without donor labels."
  )
}
gmt_path <- "config/gene_sets.gmt"
if (!file.exists(gmt_path)) stop("Missing gene sets; run scripts/prepare_gene_sets.py")

obj <- readRDS(input)
if (!inherits(obj, "Seurat")) stop("Expected a Seurat object")
required_meta <- c("donor_id", "condition", "tissue", "cell_type")
assert_columns(obj[[]], required_meta, "single-cell metadata")
if (anyNA(obj$donor_id) || any(!nzchar(as.character(obj$donor_id)))) stop("Every cell needs donor_id")

read_gmt <- function(path) {
  lines <- strsplit(readLines(path, warn = FALSE), "\t", fixed = TRUE)
  stats::setNames(lapply(lines, function(x) unique(x[-c(1, 2)])), vapply(lines, `[[`, character(1), 1))
}
gene_sets <- read_gmt(gmt_path)
md_genes <- gene_sets[["LU2025_MD_SCORE"]]
if (is.null(md_genes) || length(md_genes) < 100) stop("Author-derived MD signature is incomplete")

# Scores are descriptive at cell level; all disease tests below aggregate by donor.
obj <- UCell::AddModuleScore_UCell(obj, features = gene_sets, assay = "RNA", name = NULL)
score_cols <- paste0(names(gene_sets), "_UCell")
missing_scores <- setdiff(score_cols, colnames(obj[[]]))
if (length(missing_scores)) stop("UCell did not produce: ", paste(missing_scores, collapse = ", "))

score_dat <- obj[[]][, c(required_meta, score_cols), drop = FALSE]
score_dat$cell_barcode <- rownames(score_dat)
donor_scores <- score_dat |>
  dplyr::group_by(donor_id, condition, tissue, cell_type) |>
  dplyr::summarise(dplyr::across(dplyr::all_of(score_cols), median, na.rm = TRUE),
    n_cells = dplyr::n(), .groups = "drop")
write_audit_tsv(as.data.frame(donor_scores), "single_cell_donor_program_scores.tsv")

md_col <- "LU2025_MD_SCORE_UCell"
control_cols <- c("ECM_COLLAGEN_CORE_UCell", "MYOFIBROBLAST_CORE_UCell", "LU2025_TGFB_SCORE_UCell")
cor_rows <- lapply(control_cols, function(control) {
  data.frame(program = control, rho = cor(donor_scores[[md_col]], donor_scores[[control]],
    method = "spearman", use = "pairwise.complete.obs"))
})
cor_tab <- data.table::rbindlist(cor_rows)
cor_tab[, remove_md_for_collinearity := abs(rho) >= cfg$single_cell$md_remove_if_correlation_ge]
write_audit_tsv(cor_tab, "md_specificity_correlations.tsv")

# Donor-by-cell-type pseudobulk. Integrated/batch-corrected values are never used.
counts <- Seurat::LayerData(obj, assay = "RNA", layer = "counts")
group <- interaction(obj$donor_id, obj$cell_type, drop = TRUE, sep = "||")
pb <- Matrix::sparse.model.matrix(~ 0 + group)
pseudobulk <- counts %*% pb
colnames(pseudobulk) <- sub("^group", "", colnames(pseudobulk))
saveRDS(pseudobulk, "data/derived/GSE173252_pseudobulk_counts.rds")

sample_info <- unique(data.frame(
  pseudobulk_id = as.character(group), donor_id = obj$donor_id,
  condition = obj$condition, tissue = obj$tissue, cell_type = obj$cell_type
))
sample_info$n_cells <- as.integer(table(group)[sample_info$pseudobulk_id])
sample_info <- sample_info[sample_info$n_cells >= cfg$single_cell$pseudobulk_min_cells, ]
write_audit_tsv(sample_info, "single_cell_pseudobulk_samples.tsv")

de_results <- list()
for (ct in unique(sample_info$cell_type)) {
  meta <- sample_info[sample_info$cell_type == ct & sample_info$condition %in% c("Dupuytren", "Skoog"), ]
  if (length(unique(meta$donor_id[meta$condition == "Dupuytren"])) < 2 ||
      length(unique(meta$donor_id[meta$condition == "Skoog"])) < 2) next
  y <- edgeR::DGEList(pseudobulk[, meta$pseudobulk_id, drop = FALSE])
  keep <- edgeR::filterByExpr(y, group = meta$condition)
  y <- edgeR::calcNormFactors(y[keep, , keep.lib.sizes = FALSE])
  design <- model.matrix(~ 0 + condition, meta)
  y <- edgeR::estimateDisp(y, design, robust = TRUE)
  fit <- edgeR::glmQLFit(y, design, robust = TRUE)
  contrast <- limma::makeContrasts(conditionDupuytren - conditionSkoog, levels = design)
  tab <- edgeR::topTags(edgeR::glmQLFTest(fit, contrast = contrast), n = Inf)$table
  tab$gene <- rownames(tab)
  tab$cell_type <- ct
  de_results[[ct]] <- tab
}
if (!length(de_results)) stop("No cell type had at least two donors per primary fascia contrast")
write_audit_tsv(data.table::rbindlist(de_results, fill = TRUE), "single_cell_pseudobulk_de.tsv")

# The article-level MD decision is deliberately explicit.
md_decision <- data.frame(
  criterion = c("absolute correlation >= threshold", "adjusted disease association"),
  failed = c(any(cor_tab$remove_md_for_collinearity), NA),
  note = c("Automatic from donor-level scores", "Set after prespecified adjusted model is reviewed")
)
write_audit_tsv(md_decision, "md_narrative_decision.tsv")


#!/usr/bin/env Rscript
source("R/utils.R")
cfg <- read_analysis_config()
candidate_path <- "results/tables/mr_candidates.tsv"
manifest_path <- "data/derived/coloc_region_manifest.tsv"
if (!file.exists(candidate_path)) stop("Missing MR candidate table: ", candidate_path)
if (!file.exists(manifest_path)) stop("Missing regional data manifest: ", manifest_path)

candidates <- data.table::fread(candidate_path)
manifest <- data.table::fread(manifest_path)
assert_columns(manifest, c("lipid", "exposure_file", "outcome_file", "region_id"), "coloc manifest")

run_one <- function(row) {
  exp <- data.table::fread(row$exposure_file)
  out <- data.table::fread(row$outcome_file)
  req <- c("SNP", "beta", "varbeta", "MAF", "N")
  assert_columns(exp, req, paste0("exposure region ", row$region_id))
  assert_columns(out, c(req, "s"), paste0("outcome region ", row$region_id))
  merged <- merge(exp, out, by = "SNP", suffixes = c(".exp", ".out"))
  if (nrow(merged) < 50) stop("Too few overlapping variants for ", row$region_id)
  fit <- coloc::coloc.abf(
    dataset1 = list(beta = merged$beta.exp, varbeta = merged$varbeta.exp,
      snp = merged$SNP, MAF = merged$MAF.exp, N = unique(merged$N.exp)[1], type = "quant"),
    dataset2 = list(beta = merged$beta.out, varbeta = merged$varbeta.out,
      snp = merged$SNP, MAF = merged$MAF.out, N = unique(merged$N.out)[1],
      s = unique(merged$s)[1], type = "cc"),
    p1 = cfg$colocalization$priors$primary$p1,
    p2 = cfg$colocalization$priors$primary$p2,
    p12 = cfg$colocalization$priors$primary$p12
  )
  data.frame(lipid = row$lipid, region_id = row$region_id,
    n_overlap = nrow(merged), pp_h0 = fit$summary[["PP.H0.abf"]],
    pp_h1 = fit$summary[["PP.H1.abf"]], pp_h2 = fit$summary[["PP.H2.abf"]],
    pp_h3 = fit$summary[["PP.H3.abf"]], pp_h4 = fit$summary[["PP.H4.abf"]])
}

rows <- split(manifest, seq_len(nrow(manifest)))
res <- data.table::rbindlist(lapply(rows, run_one), fill = TRUE)
res[, tier1_coloc := pp_h4 >= cfg$colocalization$pp_h4_tier1]
write_audit_tsv(res, "colocalization_primary.tsv")


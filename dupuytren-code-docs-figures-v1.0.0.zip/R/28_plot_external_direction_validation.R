#!/usr/bin/env Rscript
source("R/utils.R")

# Display only the 13 genes independently fixed by GSE173252 + GSE75152 before
# opening the author-selected Zenodo list. This is a restricted direction check,
# not a new discovery analysis.
tab <- data.table::fread("results/tables/scrna_GSE75152_Zenodo14017529_direction.tsv")
if (!nrow(tab)) stop("No overlapping genes for external direction plot")
tab[, label := ifelse(gene %in% c("CTHRC1", "MMP11", "P4HA3", "SPARC", "TGFBI"), gene, "")]
p <- ggplot2::ggplot(tab, ggplot2::aes(x = GSE75152_logFC, y = Zenodo_logFC)) +
  ggplot2::geom_hline(yintercept = 0, linewidth = 0.3, colour = "grey70") +
  ggplot2::geom_vline(xintercept = 0, linewidth = 0.3, colour = "grey70") +
  ggplot2::geom_point(size = 2.8, colour = "#A33B36") +
  ggplot2::geom_text(ggplot2::aes(label = label), nudge_y = 0.14, check_overlap = TRUE, size = 3) +
  ggplot2::labs(
    title = "Restricted external direction check",
    subtitle = "13 genes preselected by GSE173252 mesenchyme + GSE75152; Zenodo contains author-selected genes only",
    x = "GSE75152 log2 fold change (Dupuytren - control)",
    y = "Zenodo 14017529 reanalysis log2 fold change (Dupuytren - control)"
  ) +
  ggplot2::theme_classic(base_size = 11) +
  ggplot2::theme(plot.title = ggplot2::element_text(face = "bold"), plot.subtitle = ggplot2::element_text(size = 9))
out <- file.path(project_root(), "results", "figures", "external_direction_validation.png")
ensure_dir(dirname(out))
ggplot2::ggsave(out, p, width = 7.2, height = 5.2, dpi = 300, bg = "white")
message("Wrote ", out)

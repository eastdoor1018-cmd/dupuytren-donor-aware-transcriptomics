#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dupuytren_lipidomics.cadby import parse_supplementary_data_6, parse_supplementary_data_8
from dupuytren_lipidomics.catalog import download, gwas_catalog_directory, sha256, write_manifest
from dupuytren_lipidomics.landstra import parse_meta_model1
from dupuytren_lipidomics.sumstats import extract_variants

EPMC_ARCHIVE = "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC9170690/supplementaryFiles"
CADBY_FILES = {
    "41467_2022_30875_MOESM8_ESM.xlsx": "Cadby2022_Supplementary_Data_6.xlsx",
    "41467_2022_30875_MOESM10_ESM.xlsx": "Cadby2022_Supplementary_Data_8.xlsx",
}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def bootstrap() -> list[dict]:
    raw = ROOT / "data" / "raw" / "cadby_2022"
    derived = ROOT / "data" / "derived"
    archive = download(EPMC_ARCHIVE, raw / "PMC9170690_supplementary.zip", timeout=180)
    records: list[dict] = []
    with zipfile.ZipFile(archive) as bundle:
        for member, clean_name in CADBY_FILES.items():
            target = raw / clean_name
            if not target.exists() or not zipfile.is_zipfile(target):
                with bundle.open(member) as source, target.open("wb") as output:
                    output.write(source.read())
            records.append({"stage": "bootstrap", "url": EPMC_ARCHIVE, "path": str(target.relative_to(ROOT)),
                "bytes": target.stat().st_size, "sha256": sha256(target), "downloaded_at": now()})

    counts6 = parse_supplementary_data_6(
        raw / "Cadby2022_Supplementary_Data_6.xlsx",
        derived / "cadby_2022_supplementary_data_6.tsv",
    )
    counts8 = parse_supplementary_data_8(
        raw / "Cadby2022_Supplementary_Data_8.xlsx",
        derived / "cadby_2022_supplementary_data_8.tsv",
    )
    print(json.dumps({"supplementary_data_6": counts6, "supplementary_data_8": counts8}, indent=2))
    return records


def primary_mr() -> list[dict]:
    instruments = ROOT / "data" / "derived" / "cadby_2022_supplementary_data_6.tsv"
    if not instruments.exists():
        raise SystemExit("Bootstrap data are missing; run --tier bootstrap first")
    with instruments.open(encoding="utf-8") as handle:
        variants = {row["SNP"] for row in csv.DictReader(handle, delimiter="\t") if row.get("SNP")}

    accession = "GCST90301252"
    directory = gwas_catalog_directory(accession)
    raw_dir = ROOT / "data" / "raw" / "gwas_catalog" / accession
    stats = download(directory + f"{accession}.tsv", raw_dir / f"{accession}.tsv", timeout=180)
    metadata_name = f"{accession}.tsv-meta.yaml"
    metadata = download(directory + metadata_name, raw_dir / metadata_name, timeout=90)
    output = ROOT / "data" / "derived" / f"{accession}_instrument_associations.tsv"
    counts = extract_variants(stats, variants, output)
    print(json.dumps({"outcome_extraction": counts}, indent=2))
    return [
        {"stage": "primary-mr", "url": directory + stats.name, "path": str(stats.relative_to(ROOT)),
            "bytes": stats.stat().st_size, "sha256": sha256(stats), "downloaded_at": now()},
        {"stage": "primary-mr", "url": directory + metadata.name, "path": str(metadata.relative_to(ROOT)),
            "bytes": metadata.stat().st_size, "sha256": sha256(metadata), "downloaded_at": now()},
    ]


def candidate_download(candidate_table: Path | None) -> list[dict]:
    if candidate_table is None or not candidate_table.exists():
        raise SystemExit("--candidate-table must point to the completed MR candidate TSV")
    raise SystemExit(
        "Candidate acquisition is intentionally gated: accession-to-lipid mapping and regional windows "
        "must be frozen from the GWAS Catalog metadata before full files are fetched."
    )


def expression() -> list[dict]:
    registry = ROOT / "data" / "derived" / "expression_download_registry.tsv"
    registry.parent.mkdir(parents=True, exist_ok=True)
    rows = [
        ("GSE173252", "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE173nnn/GSE173252/suppl/GSE173252_RAW.tar", "main scRNA raw matrices"),
        ("GSE75152", "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE75nnn/GSE75152/matrix/GSE75152_series_matrix.txt.gz", "bulk validation matrix"),
    ]
    with registry.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(["accession", "url", "role", "download_status"])
        writer.writerows((*row, "registered_not_downloaded") for row in rows)
    print(f"Expression registry written to {registry}; large files are not downloaded until MR yields candidates.")
    return []


def stage2_bootstrap() -> list[dict]:
    """Acquire and parse the Landstra 2026 public supplementary instrument table."""
    raw = ROOT / "data" / "raw" / "landstra_2026"
    archive_url = "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13135507/supplementaryFiles"
    archive = download(archive_url, raw / "PMC13135507_supplementary.zip", timeout=240)
    member = "41467_2026_72542_MOESM3_ESM.xlsx"
    workbook = raw / member
    if not workbook.exists() or not zipfile.is_zipfile(workbook):
        with zipfile.ZipFile(archive) as bundle:
            with bundle.open(member) as source, workbook.open("wb") as output:
                output.write(source.read())
    destination = ROOT / "data" / "derived" / "landstra_2026_meta_model1_instruments.tsv"
    counts = parse_meta_model1(workbook, destination)
    print(json.dumps({"landstra_2026_meta_model1": counts}, indent=2))
    return [
        {"stage": "stage2-bootstrap", "url": archive_url,
         "path": str(archive.relative_to(ROOT)), "bytes": archive.stat().st_size,
         "sha256": sha256(archive), "downloaded_at": now()},
        {"stage": "stage2-bootstrap", "url": archive_url + "#" + member,
         "path": str(workbook.relative_to(ROOT)), "bytes": workbook.stat().st_size,
         "sha256": sha256(workbook), "downloaded_at": now()},
    ]


def stage2_outcome() -> list[dict]:
    instruments = ROOT / "data" / "derived" / "stage2_mr_exposure_instruments.tsv"
    if not instruments.exists():
        raise SystemExit("Stage 2 clumped instruments are missing; run R/08_prepare_stage2_inputs.R")
    with instruments.open(encoding="utf-8") as handle:
        variants = {row["SNP"] for row in csv.DictReader(handle, delimiter="\t") if row.get("SNP")}
    source = ROOT / "data" / "raw" / "gwas_catalog" / "GCST90301252" / "GCST90301252.tsv"
    if not source.exists():
        raise SystemExit("Primary Dupuytren outcome is missing; run --tier primary-mr first")
    destination = ROOT / "data" / "derived" / "stage2_GCST90301252_instrument_associations.tsv"
    counts = extract_variants(source, variants, destination)
    print(json.dumps({"stage2_outcome_extraction": counts}, indent=2))
    return []


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tier", required=True, choices=(
        "bootstrap", "primary-mr", "candidates", "expression", "stage2-bootstrap", "stage2-outcome"
    ))
    parser.add_argument("--candidate-table", type=Path)
    args = parser.parse_args()

    actions = {
        "bootstrap": bootstrap,
        "primary-mr": primary_mr,
        "candidates": lambda: candidate_download(args.candidate_table),
        "expression": expression,
        "stage2-bootstrap": stage2_bootstrap,
        "stage2-outcome": stage2_outcome,
    }
    records = actions[args.tier]()
    if records:
        write_manifest(records, ROOT / "results" / "logs" / f"download_manifest_{args.tier}.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

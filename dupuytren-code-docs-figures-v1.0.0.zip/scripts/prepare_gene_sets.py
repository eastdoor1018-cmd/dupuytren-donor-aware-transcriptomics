#!/usr/bin/env python3
from __future__ import annotations

import csv
import re
import sys
from pathlib import Path

from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "data/raw/lu_2025_md/Cell2025_mmc3.xlsx"
OUTPUT = ROOT / "config/gene_sets.gmt"

CURATED = {
    "MYOFIBROBLAST_CORE": ("prespecified core markers", ["ACTA2", "TAGLN", "MYL9", "TPM2", "CNN1", "CALD1", "MYLK"]),
    "ECM_COLLAGEN_CORE": ("prespecified ECM control", ["COL1A1", "COL1A2", "COL3A1", "COL5A1", "COL5A2", "FN1", "POSTN", "DCN", "LUM", "LOX", "THBS2"]),
    "TGF_BETA_RESPONSE_CORE": ("prespecified TGF-beta control", ["SERPINE1", "CCN2", "TGFBI", "SMAD7", "PMEPA1", "THBS1", "COL1A1", "COL3A1"]),
    "CELL_CYCLE_CORE": ("prespecified cell-cycle control", ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM3", "MCM4", "MCM5", "MCM6", "MCM7"]),
    "SPHINGOLIPID_METABOLISM_CORE": ("prespecified lipid program", ["SPTLC1", "SPTLC2", "CERS2", "CERS5", "CERS6", "SGMS1", "SGMS2", "SMPD1", "SMPD2", "ASAH1", "SPHK1", "SPHK2", "SGPL1"]),
    "GLYCEROPHOSPHOLIPID_METABOLISM_CORE": ("prespecified lipid program", ["CHKA", "CHKB", "PCYT1A", "PCYT1B", "CEPT1", "LPCAT1", "LPCAT2", "LPCAT3", "PLA2G4A", "PLD1", "PLD2"]),
    "FATTY_ACID_OXIDATION_CORE": ("prespecified lipid program", ["CPT1A", "CPT2", "ACADM", "ACADL", "ACADVL", "HADHA", "HADHB", "ECHS1", "ETFA", "ETFB"]),
    "CHOLESTEROL_HOMEOSTASIS_CORE": ("prespecified lipid program", ["SREBF2", "HMGCR", "HMGCS1", "LDLR", "SQLE", "LSS", "ABCA1", "ABCG1", "INSIG1"]),
}


def clean(values):
    # The source workbook includes occasional Excel-formatted dates in long
    # signature columns. Retain only plausible HGNC-style symbols; this keeps
    # hyphenated names such as HLA-DRB1 while excluding dates and prose.
    return [
        token for value in values if value not in (None, "")
        for token in [str(value).strip()]
        if re.fullmatch(r"[A-Za-z][A-Za-z0-9-]*", token)
    ]


def main() -> int:
    if not SOURCE.exists():
        raise SystemExit(f"Missing author supplementary file: {SOURCE}")
    workbook = load_workbook(SOURCE, read_only=True, data_only=True)
    md = workbook["MD_signatures"]
    md_columns = list(zip(*md.iter_rows(min_row=2, values_only=True)))
    sets = {
        "LU2025_MD_SCORE": ("Lu et al. Cell 2025 Supplementary Table S3", clean(md_columns[0])),
        "LU2025_TGFB_SCORE": ("Lu et al. Cell 2025 Supplementary Table S3", clean(md_columns[1])),
    }
    fibro = workbook["Fibroblast_subtype_signatures"]
    headers = [str(value) for value in next(fibro.iter_rows(min_row=1, max_row=1, values_only=True))]
    columns = list(zip(*fibro.iter_rows(min_row=2, values_only=True)))
    for header, values in zip(headers, columns):
        sets[f"LU2025_FIBRO_{header.upper()}"] = (
            "Lu et al. Cell 2025 Supplementary Table S3", clean(values)
        )
    sets.update(CURATED)
    with OUTPUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        for name, (source, genes) in sets.items():
            writer.writerow([name, source, *dict.fromkeys(genes)])
    print(f"Wrote {len(sets)} gene sets to {OUTPUT}")
    print(f"LU2025_MD_SCORE contains {len(sets['LU2025_MD_SCORE'][1])} genes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

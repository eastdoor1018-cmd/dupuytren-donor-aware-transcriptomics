#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def main() -> int:
    registry = ROOT / "config" / "datasets.tsv"
    with registry.open(encoding="utf-8") as handle:
        datasets = list(csv.DictReader(handle, delimiter="\t"))
    checks = {
        "dataset_registry_rows": len(datasets),
        "cadby_data_6": (ROOT / "data/raw/cadby_2022/Cadby2022_Supplementary_Data_6.xlsx").exists(),
        "cadby_parsed": (ROOT / "data/derived/cadby_2022_supplementary_data_6.tsv").exists(),
        "primary_outcome": (ROOT / "data/raw/gwas_catalog/GCST90301252/GCST90301252.tsv").exists(),
        "mr_results": (ROOT / "results/tables/mr_primary.tsv").exists(),
        "coloc_results": (ROOT / "results/tables/colocalization_primary.tsv").exists(),
    }
    print(json.dumps(checks, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


#!/usr/bin/env python3
"""Create a donor-level sample manifest directly from GEO SOFT metadata."""
from __future__ import annotations

import csv
import gzip
import re
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
URL = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE173nnn/GSE173252/soft/GSE173252_family.soft.gz"
SOURCE = ROOT / "data" / "raw" / "geo" / "GSE173252" / "GSE173252_family.soft.gz"
DESTINATION = ROOT / "data" / "derived" / "GSE173252_sample_manifest.tsv"


def fetch() -> None:
    SOURCE.parent.mkdir(parents=True, exist_ok=True)
    if SOURCE.exists() and SOURCE.stat().st_size > 0:
        return
    request = urllib.request.Request(URL, headers={"User-Agent": "dupuytren-fascia-study/0.1"})
    with urllib.request.urlopen(request, timeout=90) as response, SOURCE.open("wb") as handle:
        handle.write(response.read())


def classify(title: str, source: str) -> tuple[str, str]:
    value = f"{title} {source}".lower()
    if "skoog" in value:
        return "Skoog", "Skoog_fascia"
    if "dermis" in value:
        return "Dermis", "healthy_dermis"
    if re.search(r"\bdd\s*\d", value) or "dupuytren" in value:
        return "Dupuytren", "Dupuytren_fascia"
    raise ValueError(f"Cannot map GSE173252 sample: title={title!r}, source={source!r}")


def main() -> int:
    fetch()
    records: list[dict[str, str]] = []
    current: dict[str, str] | None = None
    with gzip.open(SOURCE, "rt", encoding="utf-8") as handle:
        for line in handle:
            line = line.rstrip("\n")
            if line.startswith("^SAMPLE = "):
                if current:
                    records.append(current)
                current = {"gsm": line.removeprefix("^SAMPLE = ")}
            elif current and line.startswith("!Sample_title = "):
                current["sample_title"] = line.removeprefix("!Sample_title = ")
            elif current and line.startswith("!Sample_source_name_ch1 = "):
                current["source_name"] = line.removeprefix("!Sample_source_name_ch1 = ")
        if current:
            records.append(current)
    rows = []
    for record in records:
        condition, tissue = classify(record.get("sample_title", ""), record.get("source_name", ""))
        title = record["sample_title"]
        # The public GEO metadata supplies sample IDs rather than an explicit
        # cross-tissue pairing variable. Treat each sample as a donor replicate.
        rows.append({
            "gsm": record["gsm"],
            "sample_title": title,
            "donor_id": title.replace(" ", "_"),
            "condition": condition,
            "tissue": tissue,
            "primary_fascia_contrast": str(condition in {"Dupuytren", "Skoog"}).upper(),
            "metadata_note": "GEO sample treated as donor; pairing not assumed",
        })
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with DESTINATION.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} samples to {DESTINATION}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/bin/sh
set -eu

project_root="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
export MAMBA_ROOT_PREFIX="${project_root}/.mamba"
if [ -f "${project_root}/data/reference/EUR.bed" ]; then
  export DUPUYTREN_LD_PREFIX="${project_root}/data/reference/EUR"
fi
export PLINK_BIN="${project_root}/.mamba/envs/dupuytren/bin/plink"
exec "${project_root}/.tools/bin/micromamba" run -n dupuytren "$@"
